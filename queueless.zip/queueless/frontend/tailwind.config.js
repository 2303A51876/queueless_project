/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{js,jsx}'],
  theme: {
    extend: {
      colors: {
        bg: {
          main: '#070B14',
          secondary: '#0B1220',
          navy: '#101B35',
          deepnavy: '#162447'
        },
        text: {
          primary: '#F8FAFC',
          soft: '#E5E7EB',
          muted: '#CBD5E1',
          dim: '#94A3B8'
        },
        blue: {
          electric: '#2563EB',
          bright: '#3B82F6'
        },
        pink: {
          dark: '#BE185D',
          deep: '#9D174D',
          accent: '#EC4899'
        },
        state: {
          success: '#22C55E',
          warning: '#F59E0B',
          danger: '#EF4444'
        }
      },
      fontFamily: {
        sans: ['Inter', 'system-ui', 'sans-serif']
      },
      boxShadow: {
        glow: '0 0 25px rgba(37, 99, 235, 0.15)',
        glowpink: '0 0 25px rgba(236, 72, 153, 0.15)'
      },
      backdropBlur: {
        xs: '2px'
      }
    }
  },
  plugins: []
};
