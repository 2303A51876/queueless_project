import React, { createContext, useState, useEffect, useCallback } from 'react';
import { loginApi, registerApi, getMeApi } from '../services/authApi';

export const AuthContext = createContext(null);

export const AuthProvider = ({ children }) => {
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(true);

  const bootstrap = useCallback(async () => {
    const token = localStorage.getItem('queueless_token');
    if (!token) {
      setLoading(false);
      return;
    }
    try {
      const { data } = await getMeApi();
      setUser(data.user);
    } catch (err) {
      localStorage.removeItem('queueless_token');
      localStorage.removeItem('queueless_user');
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    bootstrap();
  }, [bootstrap]);

  const login = async (email, password) => {
    const { data } = await loginApi({ email, password });
    localStorage.setItem('queueless_token', data.token);
    localStorage.setItem('queueless_user', JSON.stringify(data.user));
    setUser(data.user);
    return data.user;
  };

  const register = async (name, email, password) => {
    const { data } = await registerApi({ name, email, password });
    localStorage.setItem('queueless_token', data.token);
    localStorage.setItem('queueless_user', JSON.stringify(data.user));
    setUser(data.user);
    return data.user;
  };

  const logout = () => {
    localStorage.removeItem('queueless_token');
    localStorage.removeItem('queueless_user');
    setUser(null);
  };

  return (
    <AuthContext.Provider value={{ user, setUser, loading, login, register, logout }}>
      {children}
    </AuthContext.Provider>
  );
};
