import api from './api';

export const joinQueueApi = (serviceId) => api.post('/queues/join', { serviceId });
export const getMyQueuesApi = () => api.get('/queues/my');
export const snoozeTokenApi = (id, minutes) => api.put(`/queues/${id}/snooze`, { minutes });
export const cancelTokenApi = (id) => api.put(`/queues/${id}/cancel`);
export const transferTokenApi = (id, newServiceId) => api.put(`/queues/${id}/transfer`, { newServiceId });

// Admin/staff queue control
export const listAllTokensApi = (params) => api.get('/queues/admin/all', { params });
export const callNextTokenApi = (serviceId, counterId) => api.post('/queues/admin/next', { serviceId, counterId });
export const completeTokenApi = (id) => api.put(`/queues/admin/${id}/complete`);
export const markNoShowApi = (id) => api.put(`/queues/admin/${id}/no-show`);
export const recallTokenApi = (id) => api.put(`/queues/admin/${id}/recall`);
export const adminCancelTokenApi = (id) => api.put(`/queues/admin/${id}/cancel`);
