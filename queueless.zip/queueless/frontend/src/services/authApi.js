import api from './api';

export const registerApi = (payload) => api.post('/auth/register', payload);
export const loginApi = (payload) => api.post('/auth/login', payload);
export const getMeApi = () => api.get('/auth/me');
export const updatePriorityStatusApi = (priorityStatus) =>
  api.put('/users/priority-status', { priorityStatus });
