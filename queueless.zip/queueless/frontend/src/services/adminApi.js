import api from './api';

export const getCountersApi = () => api.get('/counters');
export const createCounterApi = (payload) => api.post('/counters', payload);
export const updateCounterApi = (id, payload) => api.put(`/counters/${id}`, payload);
export const deleteCounterApi = (id) => api.delete(`/counters/${id}`);

export const getAppointmentsApi = () => api.get('/appointments');
export const createAppointmentApi = (payload) => api.post('/appointments', payload);
export const updateAppointmentApi = (id, payload) => api.put(`/appointments/${id}`, payload);

export const getAnalyticsApi = () => api.get('/analytics');
export const getAuditLogsApi = () => api.get('/audit-logs');
export const getUsersApi = () => api.get('/users');
export const updateUserApi = (id, payload) => api.put(`/users/${id}`, payload);
