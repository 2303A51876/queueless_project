import api from './api';

export const getServicesApi = () => api.get('/services');
export const getServiceByIdApi = (id) => api.get(`/services/${id}`);
export const createServiceApi = (payload) => api.post('/services', payload);
export const updateServiceApi = (id, payload) => api.put(`/services/${id}`, payload);
export const deleteServiceApi = (id) => api.delete(`/services/${id}`);
export const pauseServiceApi = (id) => api.put(`/services/${id}/pause`);
export const resumeServiceApi = (id) => api.put(`/services/${id}/resume`);
