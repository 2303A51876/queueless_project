import React, { useEffect, useState, useCallback, useRef } from 'react';
import { Radar } from 'lucide-react';
import useSocket from '../hooks/useSocket';
import { getServicesApi } from '../services/serviceApi';
import { listAllTokensApi } from '../services/queueApi';

const Display = () => {
  const { socket } = useSocket();
  const [services, setServices] = useState([]);
  const [waitingByService, setWaitingByService] = useState({});
  const [announcement, setAnnouncement] = useState(null);
  const [flash, setFlash] = useState(false);
  const [lastCalled, setLastCalled] = useState(null);
  const [clock, setClock] = useState(new Date());
  const chimeRef = useRef(null);

  const load = useCallback(async () => {
    try {
      const { data } = await getServicesApi();
      setServices(data.services);

      const waitingCounts = {};
      await Promise.all(
        data.services.map(async (s) => {
          const tokensRes = await listAllTokensApi({ service: s._id, status: 'waiting' });
          waitingCounts[s._id] = tokensRes.data.tokens.slice(0, 5);
        })
      ).catch(() => {});
      setWaitingByService(waitingCounts);
    } catch (err) {
      console.error(err);
    }
  }, []);

  useEffect(() => {
    load();
    const timer = setInterval(() => setClock(new Date()), 1000);
    return () => clearInterval(timer);
  }, [load]);

  useEffect(() => {
    if (!socket) return;
    socket.emit('subscribeKiosk');

    const onQueueUpdated = () => load();
    const onNextCalled = (payload) => {
      setLastCalled(payload);
      setFlash(true);
      // simulate audio chime via WebAudio beep
      try {
        const ctx = new (window.AudioContext || window.webkitAudioContext)();
        const osc = ctx.createOscillator();
        const gain = ctx.createGain();
        osc.connect(gain);
        gain.connect(ctx.destination);
        osc.frequency.value = 880;
        gain.gain.setValueAtTime(0.15, ctx.currentTime);
        osc.start();
        osc.stop(ctx.currentTime + 0.35);
      } catch (e) {
        /* audio not supported */
      }
      setTimeout(() => setFlash(false), 1500);
      load();
    };
    const onAnnouncement = (payload) => {
      setAnnouncement(payload);
      setTimeout(() => setAnnouncement(null), 10000);
    };

    socket.on('queueUpdated', onQueueUpdated);
    socket.on('nextTokenCalled', onNextCalled);
    socket.on('tokenCompleted', onQueueUpdated);
    socket.on('broadcastAnnouncement', onAnnouncement);

    return () => {
      socket.off('queueUpdated', onQueueUpdated);
      socket.off('nextTokenCalled', onNextCalled);
      socket.off('tokenCompleted', onQueueUpdated);
      socket.off('broadcastAnnouncement', onAnnouncement);
    };
  }, [socket, load]);

  const currentService = lastCalled ? services.find((s) => s._id === lastCalled.serviceId) : services[0];

  return (
    <div className="min-h-screen flex flex-col animate-fade-in">
      <header className="flex items-center justify-between px-10 py-6 border-b border-white/5">
        <div className="flex items-center gap-3">
          <Radar size={28} className="text-blue-bright" />
          <span className="text-2xl font-extrabold tracking-tight">QUEUE LESS</span>
        </div>
        <div className="text-xl font-mono text-text-muted">{clock.toLocaleTimeString()}</div>
      </header>

      {announcement && (
        <div className="bg-pink-deep/90 text-white text-center py-3 px-6 text-lg font-medium animate-slide-up">
          📢 {announcement.message}
        </div>
      )}

      <main className="flex-1 flex flex-col items-center justify-center px-6 py-10">
        <p className="text-2xl md:text-3xl tracking-widest text-text-dim mb-4">NOW SERVING</p>
        <div className={`transition-transform duration-500 ${flash ? 'animate-token-pop scale-105' : ''}`}>
          <p className="text-[10rem] md:text-[16rem] leading-none font-black text-gradient drop-shadow-2xl">
            #{String(lastCalled?.tokenNumber ?? currentService?.currentServingToken ?? 0).padStart(2, '0')}
          </p>
        </div>
        <p className="text-3xl md:text-5xl font-bold text-text-primary mt-6">
          COUNTER {lastCalled?.counterNumber ?? '—'}
        </p>
        {currentService && <p className="text-lg text-text-dim mt-2">{currentService.name}</p>}
      </main>

      <section className="grid md:grid-cols-3 gap-4 px-6 pb-6">
        {services.map((s) => (
          <div key={s._id} className="glass-card p-5">
            <p className="font-semibold text-text-primary mb-2">{s.name}</p>
            <div className="flex justify-between text-sm text-text-muted mb-3">
              <span>Now Serving: #{s.currentServingToken || 0}</span>
              <span>Waiting: {s.waitingCount || 0}</span>
            </div>
            <div className="flex gap-1.5 flex-wrap">
              {(waitingByService[s._id] || []).map((t) => (
                <span key={t._id} className="text-xs px-2 py-1 rounded-md bg-white/5 text-text-muted">
                  #{t.tokenNumber}
                </span>
              ))}
            </div>
          </div>
        ))}
      </section>

      <footer className="overflow-hidden border-t border-white/5 py-3 bg-bg-secondary/60">
        <div className="whitespace-nowrap animate-[marquee_20s_linear_infinite] text-sm text-text-dim">
          {services.map((s) => `${s.name}: Now Serving #${s.currentServingToken || 0} · Waiting ${s.waitingCount || 0}`).join('    ⚡    ')}
        </div>
      </footer>

      <style>{`
        @keyframes marquee {
          0% { transform: translateX(100%); }
          100% { transform: translateX(-100%); }
        }
      `}</style>
    </div>
  );
};

export default Display;
