import React, { useState } from 'react';
import { LayoutGrid, Radar, History, ShieldCheck } from 'lucide-react';
import GlassCard from '../components/GlassCard';
import useAuth from '../hooks/useAuth';
import AvailableServices from '../dashboard/AvailableServices';
import MyQueues from '../dashboard/MyQueues';
import QueueHistory from '../dashboard/QueueHistory';
import { updatePriorityStatusApi } from '../services/authApi';
import { useToast } from '../components/Toast';

const tabs = [
  { key: 'services', label: 'Available Services', icon: LayoutGrid },
  { key: 'queues', label: 'My Live Queue & Appointments', icon: Radar },
  { key: 'history', label: 'Queue History', icon: History }
];

const greeting = () => {
  const hour = new Date().getHours();
  if (hour < 12) return 'Good Morning';
  if (hour < 18) return 'Good Afternoon';
  return 'Good Evening';
};

const Dashboard = () => {
  const { user, setUser } = useAuth();
  const { showToast } = useToast();
  const [active, setActive] = useState('services');
  const [priority, setPriority] = useState(user?.priorityStatus || 'none');
  const [saving, setSaving] = useState(false);

  const handlePriorityChange = async (value) => {
    setSaving(true);
    try {
      await updatePriorityStatusApi(value);
      setPriority(value);
      setUser((u) => ({ ...u, priorityStatus: value }));
      showToast('Priority status updated', 'success');
    } catch (err) {
      showToast('Unable to update priority status', 'error');
    } finally {
      setSaving(false);
    }
  };

  return (
    <div className="container-page py-10 animate-fade-in">
      <div className="mb-8">
        <h1 className="text-2xl md:text-3xl font-bold text-text-primary">
          {greeting()} 👋 {user?.name?.split(' ')[0]}
        </h1>
        <p className="text-text-dim mt-1 text-sm">Your queues are being tracked in real time.</p>
      </div>

      <GlassCard className="mb-8 flex flex-col md:flex-row md:items-center justify-between gap-4 animate-slide-up">
        <div className="flex items-center gap-2">
          <ShieldCheck size={18} className="text-pink-accent" />
          <div>
            <p className="text-sm font-medium text-text-primary">Priority Status</p>
            <p className="text-xs text-text-dim">Request priority handling if eligible.</p>
          </div>
        </div>
        <div className="flex gap-2">
          {['none', 'senior', 'disability'].map((val) => (
            <button
              key={val}
              disabled={saving}
              onClick={() => handlePriorityChange(val)}
              className={`px-3 py-1.5 rounded-lg text-xs font-medium capitalize transition-smooth ${
                priority === val ? 'btn-accent' : 'btn-outline'
              }`}
            >
              {val === 'none' ? 'No Priority' : val}
            </button>
          ))}
        </div>
      </GlassCard>

      <div className="flex gap-2 mb-8 overflow-x-auto pb-1">
        {tabs.map((t) => {
          const Icon = t.icon;
          return (
            <button
              key={t.key}
              onClick={() => setActive(t.key)}
              className={`flex items-center gap-2 px-4 py-2.5 rounded-xl text-sm font-medium whitespace-nowrap transition-smooth ${
                active === t.key ? 'btn-primary' : 'btn-outline'
              }`}
            >
              <Icon size={15} /> {t.label}
            </button>
          );
        })}
      </div>

      <div className="animate-tab-fade">
        {active === 'services' && <AvailableServices />}
        {active === 'queues' && <MyQueues />}
        {active === 'history' && <QueueHistory />}
      </div>
    </div>
  );
};

export default Dashboard;
