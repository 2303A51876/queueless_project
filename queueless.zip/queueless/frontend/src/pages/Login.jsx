import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { Eye, EyeOff, Radar, LogIn } from 'lucide-react';
import GlassCard from '../components/GlassCard';
import useAuth from '../hooks/useAuth';
import { useToast } from '../components/Toast';

const demoAccounts = [
  { label: 'Admin: Vasudev', email: 'vasudevadmin@example.com' },
  { label: 'Admin: Shyla Sri', email: 'shylasriadmin@example.com' },
  { label: 'Demo Staff', email: 'staff1@example.com' },
  { label: 'Demo User', email: 'alex.johnson@example.com' }
];

const Login = () => {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  const { login } = useAuth();
  const { showToast } = useToast();
  const navigate = useNavigate();

  const autoFill = (acctEmail) => {
    setEmail(acctEmail);
    setPassword('password123');
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError('');
    if (!email || !password) {
      setError('Please enter your email and password');
      return;
    }
    setLoading(true);
    try {
      await login(email, password);
      showToast('Successfully signed in', 'success');
      navigate('/dashboard');
    } catch (err) {
      setError(err.response?.data?.message || 'Unable to sign in. Please check your credentials.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="container-page py-16 flex flex-col lg:flex-row gap-8 items-start justify-center animate-fade-in">
      <GlassCard className="w-full max-w-md animate-slide-up">
        <div className="flex items-center gap-2 mb-6">
          <div className="p-2 rounded-lg bg-gradient-to-br from-blue-electric to-pink-accent">
            <Radar size={18} className="text-white" />
          </div>
          <h1 className="text-xl font-bold text-text-primary">Sign In to Queue Less</h1>
        </div>

        <form onSubmit={handleSubmit} className="flex flex-col gap-4">
          <div>
            <label className="text-xs text-text-dim mb-1 block">Email</label>
            <input
              type="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              placeholder="you@example.com"
              className="glass-input w-full px-4 py-2.5 text-sm"
            />
          </div>
          <div>
            <label className="text-xs text-text-dim mb-1 block">Password</label>
            <div className="relative">
              <input
                type={showPassword ? 'text' : 'password'}
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="••••••••"
                className="glass-input w-full px-4 py-2.5 text-sm pr-10"
              />
              <button
                type="button"
                onClick={() => setShowPassword((s) => !s)}
                className="absolute right-3 top-1/2 -translate-y-1/2 text-text-dim"
              >
                {showPassword ? <EyeOff size={16} /> : <Eye size={16} />}
              </button>
            </div>
          </div>

          {error && <p className="text-sm text-state-danger">{error}</p>}

          <button
            type="submit"
            disabled={loading}
            className="btn-primary rounded-xl py-3 text-sm font-semibold flex items-center justify-center gap-2 mt-2"
          >
            {loading ? 'Signing in...' : (
              <>
                <LogIn size={16} /> Sign In
              </>
            )}
          </button>
        </form>

        <p className="text-sm text-text-dim text-center mt-6">
          Don&apos;t have an account?{' '}
          <Link to="/register" className="text-blue-bright font-medium">
            Register
          </Link>
        </p>
      </GlassCard>

      <GlassCard pink className="w-full max-w-sm animate-slide-up">
        <h2 className="font-semibold text-text-primary mb-1">Demo Credentials</h2>
        <p className="text-xs text-text-dim mb-4">
          Quick auto-fill for exploring different roles. Password for all demo accounts:{' '}
          <span className="text-text-primary font-mono">password123</span>
        </p>
        <div className="flex flex-col gap-3">
          {demoAccounts.map((acct) => (
            <button
              key={acct.email}
              onClick={() => autoFill(acct.email)}
              className="btn-outline flex items-center justify-between px-4 py-3 rounded-xl text-sm text-left"
            >
              <span>
                <span className="block text-text-primary font-medium">{acct.label}</span>
                <span className="block text-text-dim text-xs">{acct.email}</span>
              </span>
              <span className="text-xs text-blue-bright font-medium">Auto-Fill</span>
            </button>
          ))}
        </div>
      </GlassCard>
    </div>
  );
};

export default Login;
