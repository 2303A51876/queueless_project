import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import {
  ArrowRight,
  Radar,
  ListChecks,
  ScanLine,
  BellRing,
  ChevronDown,
  Users,
  Gauge,
  Zap,
  LayoutGrid
} from 'lucide-react';
import GlassCard from '../components/GlassCard';
import LoadingSpinner from '../components/LoadingSpinner';
import useQueue from '../hooks/useQueue';

const steps = [
  { num: '01', title: 'Select Service / Slot', desc: 'Browse services and choose to join a live queue or pre-book a time slot.', icon: LayoutGrid },
  { num: '02', title: 'Track Live Position', desc: 'Watch your position and estimated wait update in real time from anywhere.', icon: Gauge },
  { num: '03', title: 'Get Served', desc: 'Get notified the moment your token is called and head to your counter.', icon: Zap }
];

const faqs = [
  {
    q: 'How does live queue tracking work?',
    a: 'Queue Less uses real-time updates so your position and estimated wait time refresh instantly as tokens are called and completed, without needing to refresh the page.'
  },
  {
    q: 'Can I book an appointment instead of waiting in a live queue?',
    a: 'Yes. Every service supports pre-booking a specific date and time slot in addition to joining the live walk-in queue.'
  },
  {
    q: 'What happens if I need to step away?',
    a: 'You can snooze your token for a short delay, transfer to another service, or cancel it entirely — all from your dashboard.'
  },
  {
    q: 'Is priority access available?',
    a: 'Users can request Senior Citizen or Disability priority status, which is reviewed and applied by staff to adjust queue ordering.'
  }
];

const FaqItem = ({ item }) => {
  const [open, setOpen] = useState(false);
  return (
    <div className="glass-card overflow-hidden">
      <button
        onClick={() => setOpen((o) => !o)}
        className="w-full flex items-center justify-between px-5 py-4 text-left"
      >
        <span className="font-medium text-text-primary">{item.q}</span>
        <ChevronDown
          size={18}
          className={`text-text-dim transition-transform duration-300 ${open ? 'rotate-180' : ''}`}
        />
      </button>
      <div
        className={`px-5 text-sm text-text-muted transition-all duration-300 overflow-hidden ${
          open ? 'max-h-40 pb-4 opacity-100' : 'max-h-0 opacity-0'
        }`}
      >
        {item.a}
      </div>
    </div>
  );
};

const Landing = () => {
  const { services, loading } = useQueue();

  return (
    <div className="animate-fade-in">
      {/* Hero */}
      <section className="container-page pt-20 pb-16 text-center">
        <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full glass-card mb-6 text-xs text-text-muted">
          <Radar size={14} className="text-blue-bright" /> Real-time queue &amp; appointment platform
        </div>
        <h1 className="hero-heading text-4xl md:text-6xl font-extrabold tracking-tight mb-6 leading-tight">
          Stop Waiting. <span className="text-gradient">Start Living.</span>
        </h1>
        <p className="text-text-muted max-w-2xl mx-auto text-base md:text-lg mb-10">
          Queue Less lets you join live queues, pre-book appointments, and track your position
          in real time — from your phone, without standing in line.
        </p>
        <div className="flex flex-wrap items-center justify-center gap-4">
          <Link to="/register" className="btn-primary px-6 py-3 rounded-xl font-semibold flex items-center gap-2">
            Get Started Free <ArrowRight size={18} />
          </Link>
          <Link to="/login" className="btn-outline px-6 py-3 rounded-xl font-semibold">
            Sign In
          </Link>
          <Link to="/register" className="btn-accent px-6 py-3 rounded-xl font-semibold">
            Book Appointment
          </Link>
        </div>
      </section>

      {/* Impact metrics */}
      <section className="container-page pb-16 grid grid-cols-2 md:grid-cols-4 gap-4 grid-cards">
        {[
          { label: 'Users Served', value: '10K+' },
          { label: 'Uptime', value: '99.9%' },
          { label: 'Update Speed', value: '<1s' },
          { label: 'Services', value: '50+' }
        ].map((m) => (
          <GlassCard key={m.label} className="text-center animate-slide-up">
            <p className="text-2xl md:text-3xl font-extrabold text-gradient">{m.value}</p>
            <p className="text-xs text-text-dim mt-1">{m.label}</p>
          </GlassCard>
        ))}
      </section>

      {/* Live queue preview */}
      <section className="container-page pb-20">
        <h2 className="text-2xl font-bold text-text-primary mb-2 text-center">Live Queue Preview</h2>
        <p className="text-text-dim text-center mb-8 text-sm">
          See real-time activity across services — no login required.
        </p>
        {loading ? (
          <LoadingSpinner label="Loading live queues..." />
        ) : (
          <div className="grid md:grid-cols-3 gap-6 grid-cards">
            {services.map((s) => (
              <GlassCard key={s._id} hover className="animate-slide-up">
                <h3 className="font-semibold text-text-primary mb-3">{s.name}</h3>
                <div className="flex justify-between items-center">
                  <div>
                    <p className="text-xs text-text-dim">Now Serving</p>
                    <p className="text-2xl font-extrabold text-gradient">
                      #{String(s.currentServingToken || 0).padStart(2, '0')}
                    </p>
                  </div>
                  <div className="text-right">
                    <p className="text-xs text-text-dim">Waiting</p>
                    <p className="text-2xl font-extrabold text-text-primary">{s.waitingCount || 0}</p>
                  </div>
                </div>
              </GlassCard>
            ))}
          </div>
        )}
      </section>

      {/* How it works */}
      <section className="container-page pb-20">
        <h2 className="text-2xl font-bold text-text-primary mb-10 text-center">How It Works</h2>
        <div className="grid md:grid-cols-3 gap-8 relative">
          {steps.map((s, i) => {
            const Icon = s.icon;
            return (
              <div key={s.num} className="relative">
                <GlassCard hover className="text-center h-full animate-slide-up">
                  <div className="w-12 h-12 mx-auto rounded-xl bg-gradient-to-br from-blue-electric to-pink-accent flex items-center justify-center mb-4">
                    <Icon size={22} className="text-white" />
                  </div>
                  <p className="text-xs text-text-dim font-mono mb-1">{s.num}</p>
                  <h3 className="font-semibold text-text-primary mb-2">{s.title}</h3>
                  <p className="text-sm text-text-muted">{s.desc}</p>
                </GlassCard>
                {i < steps.length - 1 && (
                  <div className="hidden md:block absolute top-1/2 -right-4 w-8 h-px bg-gradient-to-r from-blue-electric to-pink-accent" />
                )}
              </div>
            );
          })}
        </div>
      </section>

      {/* Service directory */}
      <section className="container-page pb-20">
        <h2 className="text-2xl font-bold text-text-primary mb-2 text-center">Service Directory</h2>
        <p className="text-text-dim text-center mb-8 text-sm">
          Explore available services and their current queue status.
        </p>
        <div className="grid md:grid-cols-3 gap-6 grid-cards">
          {services.map((s) => (
            <GlassCard key={s._id} hover className="animate-slide-up">
              <div className="flex items-center gap-2 mb-2">
                <ListChecks size={16} className="text-blue-bright" />
                <h3 className="font-semibold text-text-primary">{s.name}</h3>
              </div>
              <p className="text-sm text-text-dim mb-4">{s.description}</p>
              <div className="flex items-center justify-between text-xs text-text-muted mb-4">
                <span className="flex items-center gap-1">
                  <Users size={13} /> {s.waitingCount || 0}/{s.capacity} waiting
                </span>
                <span>
                  {s.operatingHours?.open} – {s.operatingHours?.close}
                </span>
              </div>
              <div className="flex gap-2">
                <Link to="/login" className="btn-primary flex-1 text-center rounded-lg py-2 text-xs font-medium">
                  Join
                </Link>
                <Link to="/login" className="btn-outline flex-1 text-center rounded-lg py-2 text-xs font-medium">
                  Book
                </Link>
              </div>
            </GlassCard>
          ))}
        </div>
      </section>

      {/* Features */}
      <section className="container-page pb-20 grid md:grid-cols-3 gap-6 grid-cards">
        <GlassCard hover className="animate-slide-up">
          <ScanLine size={22} className="text-blue-bright mb-3" />
          <h3 className="font-semibold text-text-primary mb-2">Digital QR Tickets</h3>
          <p className="text-sm text-text-muted">Scan-ready QR tickets for fast onsite check-in.</p>
        </GlassCard>
        <GlassCard hover className="animate-slide-up">
          <BellRing size={22} className="text-pink-accent mb-3" />
          <h3 className="font-semibold text-text-primary mb-2">Instant Notifications</h3>
          <p className="text-sm text-text-muted">Get notified in real time the moment you're called.</p>
        </GlassCard>
        <GlassCard hover className="animate-slide-up">
          <Gauge size={22} className="text-blue-bright mb-3" />
          <h3 className="font-semibold text-text-primary mb-2">Smart Wait Estimates</h3>
          <p className="text-sm text-text-muted">Dynamic estimates factor in counters, priority, and load.</p>
        </GlassCard>
      </section>

      {/* FAQ */}
      <section className="container-page pb-20 max-w-2xl mx-auto">
        <h2 className="text-2xl font-bold text-text-primary mb-8 text-center">Frequently Asked Questions</h2>
        <div className="flex flex-col gap-3">
          {faqs.map((f) => (
            <FaqItem key={f.q} item={f} />
          ))}
        </div>
      </section>
    </div>
  );
};

export default Landing;
