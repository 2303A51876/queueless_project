import React, { useState } from 'react';
import {
  LayoutDashboard,
  Building2,
  Settings2,
  ListChecks,
  CalendarClock,
  BarChart3,
  Menu,
  X
} from 'lucide-react';
import Overview from '../admin/Overview';
import CounterManagement from '../admin/CounterManagement';
import ServicesManagement from '../admin/ServicesManagement';
import QueueControl from '../admin/QueueControl';
import AppointmentManagement from '../admin/AppointmentManagement';
import AnalyticsLogs from '../admin/AnalyticsLogs';

const navItems = [
  { key: 'overview', label: 'Overview', icon: LayoutDashboard, component: Overview },
  { key: 'counters', label: 'Counter Management', icon: Building2, component: CounterManagement },
  { key: 'services', label: 'Services CRUD', icon: Settings2, component: ServicesManagement },
  { key: 'queues', label: 'Queues & Control', icon: ListChecks, component: QueueControl },
  { key: 'appointments', label: 'Appointment Scheduling', icon: CalendarClock, component: AppointmentManagement },
  { key: 'analytics', label: 'Analytics & Logs', icon: BarChart3, component: AnalyticsLogs }
];

const AdminDashboard = () => {
  const [active, setActive] = useState('overview');
  const [sidebarOpen, setSidebarOpen] = useState(false);

  const ActiveComponent = navItems.find((n) => n.key === active)?.component || Overview;

  return (
    <div className="admin-layout animate-fade-in">
      <button
        className="md:hidden fixed top-20 left-4 z-30 btn-outline p-2 rounded-lg"
        onClick={() => setSidebarOpen((o) => !o)}
      >
        {sidebarOpen ? <X size={18} /> : <Menu size={18} />}
      </button>

      <aside className={`admin-sidebar ${sidebarOpen ? 'open' : ''} bg-bg-secondary/60 border-r border-white/5 p-5`}>
        <p className="text-xs uppercase tracking-widest text-text-dim mb-4 mt-2">Admin Panel</p>
        <nav className="flex flex-col gap-1">
          {navItems.map((item) => {
            const Icon = item.icon;
            return (
              <button
                key={item.key}
                onClick={() => { setActive(item.key); setSidebarOpen(false); }}
                className={`flex items-center gap-3 px-3.5 py-2.5 rounded-xl text-sm font-medium transition-smooth text-left ${
                  active === item.key
                    ? 'bg-gradient-to-r from-blue-electric/20 to-pink-accent/20 text-text-primary border border-white/10'
                    : 'text-text-muted hover:bg-white/5'
                }`}
              >
                <Icon size={16} /> {item.label}
              </button>
            );
          })}
        </nav>
      </aside>

      <main className="p-6 md:p-8 animate-tab-fade">
        <h1 className="text-xl md:text-2xl font-bold text-text-primary mb-6">
          {navItems.find((n) => n.key === active)?.label}
        </h1>
        <ActiveComponent />
      </main>
    </div>
  );
};

export default AdminDashboard;
