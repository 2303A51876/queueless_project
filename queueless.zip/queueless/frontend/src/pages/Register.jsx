import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { Eye, EyeOff, Radar, UserPlus } from 'lucide-react';
import GlassCard from '../components/GlassCard';
import useAuth from '../hooks/useAuth';
import { useToast } from '../components/Toast';

const isEmail = (v) => /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(v);

const Register = () => {
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  const { register } = useAuth();
  const { showToast } = useToast();
  const navigate = useNavigate();

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError('');

    if (name.trim().length < 2) return setError('Please enter your full name');
    if (!isEmail(email)) return setError('Please enter a valid email address');
    if (password.length < 6) return setError('Password must be at least 6 characters');
    if (password !== confirmPassword) return setError('Passwords do not match');

    setLoading(true);
    try {
      await register(name, email, password);
      showToast('Account created successfully', 'success');
      navigate('/dashboard');
    } catch (err) {
      setError(err.response?.data?.message || 'Unable to register. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="container-page py-16 flex items-center justify-center animate-fade-in">
      <GlassCard className="w-full max-w-md animate-slide-up">
        <div className="flex items-center gap-2 mb-6">
          <div className="p-2 rounded-lg bg-gradient-to-br from-blue-electric to-pink-accent">
            <Radar size={18} className="text-white" />
          </div>
          <h1 className="text-xl font-bold text-text-primary">Create your Queue Less account</h1>
        </div>

        <form onSubmit={handleSubmit} className="flex flex-col gap-4">
          <div>
            <label className="text-xs text-text-dim mb-1 block">Full Name</label>
            <input
              value={name}
              onChange={(e) => setName(e.target.value)}
              placeholder="e.g. Jordan Lee"
              className="glass-input w-full px-4 py-2.5 text-sm"
            />
          </div>
          <div>
            <label className="text-xs text-text-dim mb-1 block">Email</label>
            <input
              type="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              placeholder="you@example.com"
              className="glass-input w-full px-4 py-2.5 text-sm"
            />
          </div>
          <div>
            <label className="text-xs text-text-dim mb-1 block">Password</label>
            <div className="relative">
              <input
                type={showPassword ? 'text' : 'password'}
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="At least 6 characters"
                className="glass-input w-full px-4 py-2.5 text-sm pr-10"
              />
              <button
                type="button"
                onClick={() => setShowPassword((s) => !s)}
                className="absolute right-3 top-1/2 -translate-y-1/2 text-text-dim"
              >
                {showPassword ? <EyeOff size={16} /> : <Eye size={16} />}
              </button>
            </div>
          </div>
          <div>
            <label className="text-xs text-text-dim mb-1 block">Confirm Password</label>
            <input
              type={showPassword ? 'text' : 'password'}
              value={confirmPassword}
              onChange={(e) => setConfirmPassword(e.target.value)}
              placeholder="Re-enter your password"
              className="glass-input w-full px-4 py-2.5 text-sm"
            />
          </div>

          {error && <p className="text-sm text-state-danger">{error}</p>}

          <button
            type="submit"
            disabled={loading}
            className="btn-accent rounded-xl py-3 text-sm font-semibold flex items-center justify-center gap-2 mt-2"
          >
            {loading ? 'Creating account...' : (
              <>
                <UserPlus size={16} /> Create Account
              </>
            )}
          </button>
        </form>

        <p className="text-sm text-text-dim text-center mt-6">
          Already have an account?{' '}
          <Link to="/login" className="text-blue-bright font-medium">
            Sign in
          </Link>
        </p>
      </GlassCard>
    </div>
  );
};

export default Register;
