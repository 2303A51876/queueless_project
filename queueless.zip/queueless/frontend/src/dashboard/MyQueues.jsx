import React, { useEffect, useState, useCallback } from 'react';
import QueueCard from '../components/QueueCard';
import QRCodeTicket from '../components/QRCodeTicket';
import LoadingSpinner from '../components/LoadingSpinner';
import ConfirmDialog from '../components/ConfirmDialog';
import Modal from '../components/Modal';
import { getMyQueuesApi, snoozeTokenApi, cancelTokenApi, transferTokenApi } from '../services/queueApi';
import { getServicesApi } from '../services/serviceApi';
import useSocket from '../hooks/useSocket';
import { useToast } from '../components/Toast';

const MyQueues = () => {
  const [tokens, setTokens] = useState([]);
  const [services, setServices] = useState([]);
  const [loading, setLoading] = useState(true);
  const [cancelTarget, setCancelTarget] = useState(null);
  const [transferTarget, setTransferTarget] = useState(null);
  const [transferServiceId, setTransferServiceId] = useState('');
  const { socket } = useSocket();
  const { showToast } = useToast();

  const load = useCallback(async () => {
    try {
      const [tokensRes, servicesRes] = await Promise.all([getMyQueuesApi(), getServicesApi()]);
      setTokens(tokensRes.data.tokens);
      setServices(servicesRes.data.services);
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    load();
  }, [load]);

  useEffect(() => {
    if (!socket) return;
    const handler = () => load();
    socket.on('queueUpdated', handler);
    socket.on('nextTokenCalled', handler);
    socket.on('tokenCompleted', handler);
    return () => {
      socket.off('queueUpdated', handler);
      socket.off('nextTokenCalled', handler);
      socket.off('tokenCompleted', handler);
    };
  }, [socket, load]);

  const activeTokens = tokens.filter((t) => ['waiting', 'called', 'serving'].includes(t.status));

  const handleSnooze = async (token) => {
    try {
      await snoozeTokenApi(token._id, 10);
      showToast('Token snoozed for 10 minutes', 'success');
      load();
    } catch (err) {
      showToast(err.response?.data?.message || 'Unable to snooze token', 'error');
    }
  };

  const handleCancel = async () => {
    try {
      await cancelTokenApi(cancelTarget._id);
      showToast('Token cancelled', 'success');
      load();
    } catch (err) {
      showToast(err.response?.data?.message || 'Unable to cancel token', 'error');
    }
  };

  const handleTransfer = async () => {
    if (!transferServiceId) {
      showToast('Please select a service to transfer to', 'warning');
      return;
    }
    try {
      await transferTokenApi(transferTarget._id, transferServiceId);
      showToast('Token transferred successfully', 'success');
      setTransferTarget(null);
      setTransferServiceId('');
      load();
    } catch (err) {
      showToast(err.response?.data?.message || 'Unable to transfer token', 'error');
    }
  };

  if (loading) return <LoadingSpinner label="Loading your queues..." />;

  if (!activeTokens.length) {
    return (
      <div className="glass-card p-10 text-center text-text-dim">
        You don&apos;t have any active queues or appointments right now. Head to Available Services to join one.
      </div>
    );
  }

  return (
    <>
      <div className="grid lg:grid-cols-2 gap-6 grid-cards">
        {activeTokens.map((token) => (
          <div key={token._id} className="flex flex-col gap-6">
            <QueueCard
              token={token}
              onSnooze={handleSnooze}
              onTransfer={setTransferTarget}
              onCancel={setCancelTarget}
            />
            <QRCodeTicket token={token} />
          </div>
        ))}
      </div>

      <ConfirmDialog
        open={!!cancelTarget}
        onClose={() => setCancelTarget(null)}
        onConfirm={handleCancel}
        title="Cancel Token"
        description={`Are you sure you want to cancel Token #${cancelTarget?.tokenNumber}? This cannot be undone.`}
        confirmLabel="Cancel Token"
        danger
      />

      <Modal open={!!transferTarget} onClose={() => setTransferTarget(null)} title="Transfer to Another Service">
        <div className="flex flex-col gap-4">
          <select
            value={transferServiceId}
            onChange={(e) => setTransferServiceId(e.target.value)}
            className="glass-input w-full px-4 py-2.5 text-sm"
          >
            <option value="">Select a service</option>
            {services
              .filter((s) => s._id !== transferTarget?.service?._id)
              .map((s) => (
                <option key={s._id} value={s._id}>
                  {s.name}
                </option>
              ))}
          </select>
          <button onClick={handleTransfer} className="btn-primary rounded-xl py-2.5 text-sm font-semibold">
            Confirm Transfer
          </button>
        </div>
      </Modal>
    </>
  );
};

export default MyQueues;
