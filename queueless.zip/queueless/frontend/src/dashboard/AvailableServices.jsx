import React, { useState } from 'react';
import ServiceCard from '../components/ServiceCard';
import LoadingSpinner from '../components/LoadingSpinner';
import Modal from '../components/Modal';
import useQueue from '../hooks/useQueue';
import { joinQueueApi } from '../services/queueApi';
import { createAppointmentApi } from '../services/adminApi';
import { useToast } from '../components/Toast';

const AvailableServices = () => {
  const { services, loading, refresh } = useQueue();
  const { showToast } = useToast();
  const [joiningId, setJoiningId] = useState(null);
  const [bookService, setBookService] = useState(null);
  const [date, setDate] = useState('');
  const [timeSlot, setTimeSlot] = useState('');
  const [booking, setBooking] = useState(false);

  const handleJoin = async (service) => {
    setJoiningId(service._id);
    try {
      await joinQueueApi(service._id);
      showToast(`Joined the ${service.name} queue`, 'success');
      refresh();
    } catch (err) {
      showToast(err.response?.data?.message || 'Unable to join queue', 'error');
    } finally {
      setJoiningId(null);
    }
  };

  const handleBookSubmit = async () => {
    if (!date || !timeSlot) {
      showToast('Please select a date and time slot', 'warning');
      return;
    }
    setBooking(true);
    try {
      await createAppointmentApi({ serviceId: bookService._id, date, timeSlot });
      showToast('Appointment booked successfully', 'success');
      setBookService(null);
      setDate('');
      setTimeSlot('');
    } catch (err) {
      showToast(err.response?.data?.message || 'Unable to book appointment', 'error');
    } finally {
      setBooking(false);
    }
  };

  if (loading) return <LoadingSpinner label="Loading services..." />;

  if (!services.length) {
    return (
      <div className="glass-card p-10 text-center text-text-dim">
        No services are available right now. Please check back later.
      </div>
    );
  }

  return (
    <>
      <div className="grid md:grid-cols-2 xl:grid-cols-3 gap-6 grid-cards">
        {services.map((s) => (
          <ServiceCard
            key={s._id}
            service={s}
            joining={joiningId === s._id}
            onJoin={handleJoin}
            onBook={setBookService}
          />
        ))}
      </div>

      <Modal open={!!bookService} onClose={() => setBookService(null)} title={`Book: ${bookService?.name || ''}`}>
        <div className="flex flex-col gap-4">
          <div>
            <label className="text-xs text-text-dim mb-1 block">Date</label>
            <input type="date" value={date} onChange={(e) => setDate(e.target.value)} className="glass-input w-full px-4 py-2.5 text-sm" />
          </div>
          <div>
            <label className="text-xs text-text-dim mb-1 block">Time Slot</label>
            <input type="time" value={timeSlot} onChange={(e) => setTimeSlot(e.target.value)} className="glass-input w-full px-4 py-2.5 text-sm" />
          </div>
          <button
            onClick={handleBookSubmit}
            disabled={booking}
            className="btn-accent rounded-xl py-2.5 text-sm font-semibold"
          >
            {booking ? 'Booking...' : 'Confirm Appointment'}
          </button>
        </div>
      </Modal>
    </>
  );
};

export default AvailableServices;
