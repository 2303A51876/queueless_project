import React, { useEffect, useState } from 'react';
import { Download, FileJson, Eye } from 'lucide-react';
import LoadingSpinner from '../components/LoadingSpinner';
import Modal from '../components/Modal';
import { getMyQueuesApi } from '../services/queueApi';

const statusColors = {
  completed: 'text-state-success bg-state-success/15',
  cancelled: 'text-state-danger bg-state-danger/15',
  'no-show': 'text-state-danger bg-state-danger/15',
  transferred: 'text-pink-accent bg-pink-accent/15'
};

const turnaround = (t) => {
  if (!t.calledAt || !t.completedAt) return '—';
  const mins = Math.round((new Date(t.completedAt) - new Date(t.calledAt)) / 60000);
  return `${mins} min`;
};

const QueueHistory = () => {
  const [tokens, setTokens] = useState([]);
  const [loading, setLoading] = useState(true);
  const [detail, setDetail] = useState(null);

  useEffect(() => {
    getMyQueuesApi()
      .then(({ data }) => setTokens(data.tokens.filter((t) => !['waiting', 'called', 'serving'].includes(t.status))))
      .finally(() => setLoading(false));
  }, []);

  const exportJSON = () => {
    const blob = new Blob([JSON.stringify(tokens, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'queueless-history.json';
    a.click();
    URL.revokeObjectURL(url);
  };

  if (loading) return <LoadingSpinner label="Loading history..." />;

  if (!tokens.length) {
    return <div className="glass-card p-10 text-center text-text-dim">No queue history yet.</div>;
  }

  return (
    <div className="glass-card p-0 overflow-hidden">
      <div className="flex items-center justify-between p-5 border-b border-white/5">
        <h3 className="font-semibold text-text-primary">Queue History</h3>
        <button onClick={exportJSON} className="btn-outline flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs">
          <FileJson size={14} /> Export JSON
        </button>
      </div>
      <table className="responsive-table w-full text-sm">
        <thead>
          <tr className="text-left text-text-dim text-xs">
            <th className="px-5 py-3">Token</th>
            <th className="px-5 py-3">Service</th>
            <th className="px-5 py-3">Date</th>
            <th className="px-5 py-3">Turnaround</th>
            <th className="px-5 py-3">Status</th>
            <th className="px-5 py-3">Actions</th>
          </tr>
        </thead>
        <tbody>
          {tokens.map((t) => (
            <tr key={t._id} className="border-t border-white/5 hover:bg-white/[0.02]">
              <td data-label="Token" className="px-5 py-3 text-text-primary font-medium">#{t.tokenNumber}</td>
              <td data-label="Service" className="px-5 py-3 text-text-muted">{t.service?.name}</td>
              <td data-label="Date" className="px-5 py-3 text-text-muted">
                {new Date(t.joinedAt || t.createdAt).toLocaleDateString()}
              </td>
              <td data-label="Turnaround" className="px-5 py-3 text-text-muted">{turnaround(t)}</td>
              <td data-label="Status" className="px-5 py-3">
                <span className={`text-xs px-2.5 py-1 rounded-full font-medium ${statusColors[t.status] || 'bg-white/5 text-text-muted'}`}>
                  {t.status}
                </span>
              </td>
              <td data-label="Actions" className="px-5 py-3">
                <button onClick={() => setDetail(t)} className="text-blue-bright text-xs flex items-center gap-1">
                  <Eye size={13} /> View
                </button>
              </td>
            </tr>
          ))}
        </tbody>
      </table>

      <Modal open={!!detail} onClose={() => setDetail(null)} title={`Token #${detail?.tokenNumber} Details`}>
        {detail && (
          <div className="text-sm text-text-muted flex flex-col gap-2">
            <p><span className="text-text-dim">Service:</span> {detail.service?.name}</p>
            <p><span className="text-text-dim">Status:</span> {detail.status}</p>
            <p><span className="text-text-dim">Joined:</span> {new Date(detail.joinedAt || detail.createdAt).toLocaleString()}</p>
            {detail.calledAt && <p><span className="text-text-dim">Called:</span> {new Date(detail.calledAt).toLocaleString()}</p>}
            {detail.completedAt && <p><span className="text-text-dim">Completed:</span> {new Date(detail.completedAt).toLocaleString()}</p>}
            <button className="btn-outline mt-3 rounded-lg py-2 text-xs flex items-center justify-center gap-2">
              <Download size={14} /> Download Receipt PDF
            </button>
          </div>
        )}
      </Modal>
    </div>
  );
};

export default QueueHistory;
