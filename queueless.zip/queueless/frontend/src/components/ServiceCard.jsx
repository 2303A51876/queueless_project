import React from 'react';
import { Clock, Users, ArrowRight, CalendarDays } from 'lucide-react';
import GlassCard from './GlassCard';

const ServiceCard = ({ service, onJoin, onBook, joining }) => {
  const estimatedWait = Math.max(
    Math.ceil(((service.waitingCount || 0) * (service.averageServiceTime || 10)) / 2),
    service.waitingCount ? 3 : 0
  );

  const isPaused = service.status !== 'active' || service.emergencyPause;

  return (
    <GlassCard hover className="animate-slide-up flex flex-col gap-4">
      <div className="flex items-start justify-between">
        <div>
          <h3 className="text-lg font-semibold text-text-primary">{service.name}</h3>
          <p className="text-sm text-text-dim mt-1">{service.description}</p>
        </div>
        <span
          className={`text-xs px-2.5 py-1 rounded-full font-medium ${
            isPaused ? 'bg-state-warning/15 text-state-warning' : 'bg-state-success/15 text-state-success'
          }`}
        >
          {isPaused ? 'Paused' : 'Active'}
        </span>
      </div>

      <div className="grid grid-cols-2 gap-3 text-sm">
        <div className="flex items-center gap-2 text-text-muted">
          <Clock size={15} className="text-blue-bright" />
          <span>
            {service.operatingHours?.open} - {service.operatingHours?.close}
          </span>
        </div>
        <div className="flex items-center gap-2 text-text-muted">
          <Users size={15} className="text-pink-accent" />
          <span>
            {service.waitingCount || 0} / {service.capacity} waiting
          </span>
        </div>
      </div>

      <div className="flex items-center justify-between bg-white/5 rounded-xl px-4 py-3">
        <div>
          <p className="text-xs text-text-dim">Estimated Wait</p>
          <p className="text-text-primary font-semibold">~{estimatedWait || 0} mins</p>
        </div>
        <div className="text-right">
          <p className="text-xs text-text-dim">Now Serving</p>
          <p className="text-text-primary font-semibold">#{service.currentServingToken || 0}</p>
        </div>
      </div>

      <div className="flex gap-3 mt-auto">
        <button
          disabled={isPaused || joining}
          onClick={() => onJoin && onJoin(service)}
          className="btn-primary flex-1 rounded-xl py-2.5 text-sm font-medium flex items-center justify-center gap-2"
        >
          {joining ? 'Joining...' : 'Join Live Queue'} <ArrowRight size={15} />
        </button>
        <button
          onClick={() => onBook && onBook(service)}
          className="btn-outline flex-1 rounded-xl py-2.5 text-sm font-medium flex items-center justify-center gap-2"
        >
          <CalendarDays size={15} /> Pre-Book
        </button>
      </div>
    </GlassCard>
  );
};

export default ServiceCard;
