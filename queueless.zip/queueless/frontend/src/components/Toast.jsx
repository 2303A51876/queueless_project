import React, { createContext, useCallback, useContext, useState } from 'react';
import { CheckCircle2, AlertTriangle, XCircle, Info } from 'lucide-react';

const ToastContext = createContext(null);

let idCounter = 0;

export const ToastProvider = ({ children }) => {
  const [toasts, setToasts] = useState([]);

  const removeToast = useCallback((id) => {
    setToasts((prev) => prev.filter((t) => t.id !== id));
  }, []);

  const showToast = useCallback(
    (message, type = 'success') => {
      const id = idCounter++;
      setToasts((prev) => [...prev, { id, message, type }]);
      setTimeout(() => removeToast(id), 4000);
    },
    [removeToast]
  );

  const iconFor = (type) => {
    if (type === 'success') return <CheckCircle2 size={18} className="text-state-success" />;
    if (type === 'warning') return <AlertTriangle size={18} className="text-state-warning" />;
    if (type === 'error') return <XCircle size={18} className="text-state-danger" />;
    return <Info size={18} className="text-blue-bright" />;
  };

  const borderFor = (type) => {
    if (type === 'success') return 'border-l-4 border-state-success';
    if (type === 'warning') return 'border-l-4 border-state-warning';
    if (type === 'error') return 'border-l-4 border-state-danger';
    return 'border-l-4 border-blue-bright';
  };

  return (
    <ToastContext.Provider value={{ showToast }}>
      {children}
      <div className="fixed top-4 right-4 z-[100] flex flex-col gap-2 max-w-xs w-full">
        {toasts.map((t) => (
          <div
            key={t.id}
            className={`glass-card ${borderFor(t.type)} animate-toast-in px-4 py-3 flex items-center gap-3 text-sm text-text-soft`}
          >
            {iconFor(t.type)}
            <span>{t.message}</span>
          </div>
        ))}
      </div>
    </ToastContext.Provider>
  );
};

export const useToast = () => {
  const ctx = useContext(ToastContext);
  if (!ctx) throw new Error('useToast must be used within a ToastProvider');
  return ctx;
};
