import React from 'react';

const LoadingSpinner = ({ size = 24, label }) => (
  <div className="flex flex-col items-center justify-center gap-3 py-6">
    <div
      className="rounded-full border-2 border-white/10 border-t-blue-bright animate-spin"
      style={{ width: size, height: size }}
    />
    {label && <p className="text-text-dim text-sm">{label}</p>}
  </div>
);

export default LoadingSpinner;
