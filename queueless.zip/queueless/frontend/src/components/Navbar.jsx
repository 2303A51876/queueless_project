import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { Radar, Menu, X, LogOut, LayoutDashboard, ShieldCheck } from 'lucide-react';
import useAuth from '../hooks/useAuth';
import LiveIndicator from './LiveIndicator';

const Navbar = () => {
  const { user, logout } = useAuth();
  const navigate = useNavigate();
  const [mobileOpen, setMobileOpen] = useState(false);

  const handleLogout = () => {
    logout();
    navigate('/');
  };

  return (
    <nav className="glass-nav sticky top-0 z-40">
      <div className="container-page flex items-center justify-between h-16">
        <Link to="/" className="flex items-center gap-2">
          <div className="p-1.5 rounded-lg bg-gradient-to-br from-blue-electric to-pink-accent">
            <Radar size={20} className="text-white" />
          </div>
          <span className="font-extrabold tracking-tight text-lg text-text-primary">QUEUE LESS</span>
        </Link>

        <div className="hidden md:flex items-center gap-6">
          <Link to="/" className="text-sm text-text-muted hover:text-text-primary transition-smooth">
            Home
          </Link>
          <Link to="/display" className="text-sm text-text-muted hover:text-text-primary transition-smooth">
            Kiosk Display
          </Link>
          <LiveIndicator />

          {user ? (
            <div className="flex items-center gap-3">
              {user.role !== 'user' && (
                <Link
                  to="/admin"
                  className="flex items-center gap-1.5 text-sm text-text-muted hover:text-text-primary transition-smooth"
                >
                  <ShieldCheck size={16} /> Admin
                </Link>
              )}
              <Link
                to="/dashboard"
                className="flex items-center gap-1.5 text-sm text-text-muted hover:text-text-primary transition-smooth"
              >
                <LayoutDashboard size={16} /> {user.name.split(' ')[0]}
              </Link>
              <button
                onClick={handleLogout}
                className="btn-outline flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-sm"
              >
                <LogOut size={14} /> Logout
              </button>
            </div>
          ) : (
            <div className="flex items-center gap-3">
              <Link to="/login" className="text-sm text-text-muted hover:text-text-primary transition-smooth">
                Sign In
              </Link>
              <Link to="/register" className="btn-primary px-4 py-2 rounded-lg text-sm font-medium">
                Get Started Free
              </Link>
            </div>
          )}
        </div>

        <button className="md:hidden text-text-primary" onClick={() => setMobileOpen((o) => !o)}>
          {mobileOpen ? <X size={22} /> : <Menu size={22} />}
        </button>
      </div>

      {mobileOpen && (
        <div className="md:hidden glass-nav border-t border-white/5 px-4 py-4 flex flex-col gap-3 animate-slide-up">
          <Link to="/" onClick={() => setMobileOpen(false)} className="text-text-muted">
            Home
          </Link>
          <Link to="/display" onClick={() => setMobileOpen(false)} className="text-text-muted">
            Kiosk Display
          </Link>
          {user ? (
            <>
              {user.role !== 'user' && (
                <Link to="/admin" onClick={() => setMobileOpen(false)} className="text-text-muted">
                  Admin Dashboard
                </Link>
              )}
              <Link to="/dashboard" onClick={() => setMobileOpen(false)} className="text-text-muted">
                My Dashboard
              </Link>
              <button onClick={handleLogout} className="btn-outline px-3 py-2 rounded-lg text-sm text-left">
                Logout
              </button>
            </>
          ) : (
            <>
              <Link to="/login" onClick={() => setMobileOpen(false)} className="text-text-muted">
                Sign In
              </Link>
              <Link to="/register" onClick={() => setMobileOpen(false)} className="btn-primary px-4 py-2 rounded-lg text-center">
                Get Started Free
              </Link>
            </>
          )}
        </div>
      )}
    </nav>
  );
};

export default Navbar;
