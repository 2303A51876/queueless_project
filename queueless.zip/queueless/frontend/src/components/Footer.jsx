import React from 'react';
import { Radar } from 'lucide-react';

const Footer = () => (
  <footer className="border-t border-white/5 mt-20">
    <div className="container-page py-10 flex flex-col md:flex-row items-center justify-between gap-4">
      <div className="flex items-center gap-2">
        <Radar size={18} className="text-blue-bright" />
        <span className="font-bold text-text-primary tracking-tight">QUEUE LESS</span>
      </div>
      <p className="text-sm text-text-dim text-center">
        Real-time queue &amp; appointment management. Built as a demo SaaS platform.
      </p>
      <p className="text-xs text-text-dim">&copy; {new Date().getFullYear()} Queue Less</p>
    </div>
  </footer>
);

export default Footer;
