import React from 'react';
import useSocket from '../hooks/useSocket';

const LiveIndicator = () => {
  const { connected } = useSocket();

  return (
    <div className="flex items-center gap-1.5 px-2.5 py-1 rounded-full bg-white/5 border border-white/10">
      <span
        className={`live-dot ${connected ? 'animate-pulse-glow' : ''}`}
        style={{ background: connected ? '#22C55E' : '#94A3B8' }}
      />
      <span className="text-xs font-medium tracking-wide text-text-muted">
        {connected ? 'LIVE' : 'OFFLINE'}
      </span>
    </div>
  );
};

export default LiveIndicator;
