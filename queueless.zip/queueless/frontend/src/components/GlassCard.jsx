import React from 'react';

const GlassCard = ({ children, className = '', pink = false, hover = false, ...rest }) => {
  const base = pink ? 'glass-card-pink' : 'glass-card';
  const hoverCls = hover ? 'feature-card' : '';
  return (
    <div className={`${base} ${hoverCls} p-6 ${className}`} {...rest}>
      {children}
    </div>
  );
};

export default GlassCard;
