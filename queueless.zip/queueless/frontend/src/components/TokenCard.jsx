import React from 'react';

const statusColors = {
  waiting: 'text-blue-bright bg-blue-electric/15',
  called: 'text-state-warning bg-state-warning/15',
  serving: 'text-state-success bg-state-success/15',
  completed: 'text-state-success bg-state-success/15',
  cancelled: 'text-state-danger bg-state-danger/15',
  'no-show': 'text-state-danger bg-state-danger/15',
  transferred: 'text-pink-accent bg-pink-accent/15'
};

const TokenCard = ({ token }) => (
  <div className="glass-card p-4 flex items-center justify-between animate-fade-in">
    <div>
      <p className="text-text-primary font-semibold">
        #{token.tokenNumber} · {token.service?.name}
      </p>
      <p className="text-xs text-text-dim mt-1">
        {new Date(token.joinedAt || token.createdAt).toLocaleString()}
      </p>
    </div>
    <span className={`text-xs px-2.5 py-1 rounded-full font-medium ${statusColors[token.status] || 'bg-white/5 text-text-muted'}`}>
      {token.status}
    </span>
  </div>
);

export default TokenCard;
