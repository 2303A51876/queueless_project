import React from 'react';
import Modal from './Modal';
import { AlertTriangle } from 'lucide-react';

const ConfirmDialog = ({ open, onClose, onConfirm, title = 'Are you sure?', description, confirmLabel = 'Confirm', danger = false }) => {
  return (
    <Modal open={open} onClose={onClose} title={title} maxWidth="max-w-sm">
      <div className="flex gap-3 mb-5">
        <AlertTriangle size={20} className={danger ? 'text-state-danger shrink-0 mt-0.5' : 'text-state-warning shrink-0 mt-0.5'} />
        <p className="text-sm text-text-muted">{description}</p>
      </div>
      <div className="flex justify-end gap-3">
        <button onClick={onClose} className="btn-outline px-4 py-2 rounded-xl text-sm font-medium">
          Cancel
        </button>
        <button
          onClick={() => {
            onConfirm();
            onClose();
          }}
          className={`${danger ? 'btn-accent' : 'btn-primary'} px-4 py-2 rounded-xl text-sm font-medium`}
        >
          {confirmLabel}
        </button>
      </div>
    </Modal>
  );
};

export default ConfirmDialog;
