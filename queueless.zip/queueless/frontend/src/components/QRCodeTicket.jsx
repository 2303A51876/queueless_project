import React from 'react';
import { QRCodeSVG } from 'qrcode.react';
import GlassCard from './GlassCard';

const QRCodeTicket = ({ token }) => {
  if (!token) return null;
  const service = token.service || {};

  return (
    <GlassCard className="flex flex-col items-center text-center gap-4 animate-scale-in">
      <p className="text-xs uppercase tracking-widest text-text-dim">Digital Queue Ticket</p>
      <div className="bg-white p-3 rounded-xl">
        <QRCodeSVG value={token.qrPayload || `TOKEN-${token.tokenNumber}`} size={140} />
      </div>
      <div className="w-full grid grid-cols-2 gap-3 text-sm text-left">
        <div>
          <p className="text-text-dim text-xs">Token Number</p>
          <p className="text-text-primary font-bold text-lg">#{token.tokenNumber}</p>
        </div>
        <div>
          <p className="text-text-dim text-xs">Service</p>
          <p className="text-text-primary font-medium">{service.name}</p>
        </div>
        <div>
          <p className="text-text-dim text-xs">Date</p>
          <p className="text-text-primary font-medium">
            {new Date(token.joinedAt || token.createdAt).toLocaleDateString()}
          </p>
        </div>
        <div>
          <p className="text-text-dim text-xs">Status</p>
          <p className="text-text-primary font-medium capitalize">{token.status}</p>
        </div>
        <div>
          <p className="text-text-dim text-xs">Counter</p>
          <p className="text-text-primary font-medium">
            {token.counter ? `Counter ${token.counter.counterNumber}` : 'Not yet assigned'}
          </p>
        </div>
      </div>
    </GlassCard>
  );
};

export default QRCodeTicket;
