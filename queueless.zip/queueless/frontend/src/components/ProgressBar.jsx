import React from 'react';

const ProgressBar = ({ value = 0, max = 100, height = 10 }) => {
  const pct = Math.min(100, Math.max(0, (value / max) * 100));
  return (
    <div className="progress-track w-full" style={{ height }}>
      <div className="progress-fill h-full animate-progress" style={{ width: `${pct}%` }} />
    </div>
  );
};

export default ProgressBar;
