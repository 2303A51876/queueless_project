import React from 'react';
import { Clock3, MapPin, TimerReset, ArrowLeftRight, XCircle } from 'lucide-react';
import GlassCard from './GlassCard';
import ProgressBar from './ProgressBar';

const statusColors = {
  waiting: 'text-blue-bright bg-blue-electric/15',
  called: 'text-state-warning bg-state-warning/15',
  serving: 'text-state-success bg-state-success/15',
  completed: 'text-text-dim bg-white/5',
  cancelled: 'text-state-danger bg-state-danger/15',
  'no-show': 'text-state-danger bg-state-danger/15',
  transferred: 'text-pink-accent bg-pink-accent/15'
};

const QueueCard = ({ token, onSnooze, onTransfer, onCancel }) => {
  const service = token.service || {};
  const nowServing = service.currentServingToken || 0;
  const position = Math.max(token.tokenNumber - nowServing, token.status === 'waiting' ? 1 : 0);
  const progressPct = nowServing && token.tokenNumber ? (nowServing / token.tokenNumber) * 100 : 0;

  return (
    <GlassCard pink className="animate-scale-in">
      <div className="flex items-center justify-between mb-6">
        <div>
          <p className="text-xs text-text-dim uppercase tracking-wide">{service.name}</p>
          <span className={`inline-block mt-1 text-xs px-2.5 py-1 rounded-full font-medium ${statusColors[token.status] || 'bg-white/5 text-text-muted'}`}>
            {token.status}
          </span>
        </div>
        <div className="text-right">
          <p className="text-xs text-text-dim">Counter</p>
          <p className="text-text-primary font-semibold flex items-center gap-1 justify-end">
            <MapPin size={14} className="text-pink-accent" />
            {token.counter ? `Counter ${token.counter.counterNumber}` : '—'}
          </p>
        </div>
      </div>

      <div className="grid grid-cols-3 gap-4 text-center mb-6">
        <div>
          <p className="text-xs text-text-dim mb-1">Your Token</p>
          <p className="text-3xl font-extrabold text-gradient">#{token.tokenNumber}</p>
        </div>
        <div>
          <p className="text-xs text-text-dim mb-1">Now Serving</p>
          <p className="text-3xl font-extrabold text-text-primary">#{nowServing}</p>
        </div>
        <div>
          <p className="text-xs text-text-dim mb-1">Your Position</p>
          <p className="text-3xl font-extrabold text-text-primary">#{position || 1}</p>
        </div>
      </div>

      <ProgressBar value={progressPct} />

      <div className="flex items-center gap-2 mt-4 text-sm text-text-muted">
        <Clock3 size={15} className="text-blue-bright" />
        <span>Estimated wait: ~{token.estimatedWaitMinutes ?? 0} mins</span>
      </div>

      {['waiting', 'called'].includes(token.status) && (
        <div className="flex flex-wrap gap-3 mt-6">
          <button
            onClick={() => onSnooze && onSnooze(token)}
            className="btn-outline flex items-center gap-1.5 px-3 py-2 rounded-lg text-xs font-medium"
          >
            <TimerReset size={14} /> Snooze 10 Mins
          </button>
          <button
            onClick={() => onTransfer && onTransfer(token)}
            className="btn-outline flex items-center gap-1.5 px-3 py-2 rounded-lg text-xs font-medium"
          >
            <ArrowLeftRight size={14} /> Transfer
          </button>
          <button
            onClick={() => onCancel && onCancel(token)}
            className="btn-outline flex items-center gap-1.5 px-3 py-2 rounded-lg text-xs font-medium text-state-danger border-state-danger/30 hover:bg-state-danger/10"
          >
            <XCircle size={14} /> Cancel
          </button>
        </div>
      )}
    </GlassCard>
  );
};

export default QueueCard;
