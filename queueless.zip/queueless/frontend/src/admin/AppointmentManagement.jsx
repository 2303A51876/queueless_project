import React, { useEffect, useState } from 'react';
import LoadingSpinner from '../components/LoadingSpinner';
import { getAppointmentsApi, updateAppointmentApi } from '../services/adminApi';
import { useToast } from '../components/Toast';

const statusColors = {
  pending: 'text-state-warning bg-state-warning/15',
  confirmed: 'text-blue-bright bg-blue-electric/15',
  rescheduled: 'text-pink-accent bg-pink-accent/15',
  completed: 'text-state-success bg-state-success/15',
  cancelled: 'text-state-danger bg-state-danger/15',
  'no-show': 'text-state-danger bg-state-danger/15'
};

const AppointmentManagement = () => {
  const [appointments, setAppointments] = useState([]);
  const [loading, setLoading] = useState(true);
  const { showToast } = useToast();

  const load = async () => {
    try {
      const { data } = await getAppointmentsApi();
      setAppointments(data.appointments);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    load();
  }, []);

  const updateStatus = async (id, status) => {
    try {
      await updateAppointmentApi(id, { status });
      showToast(`Appointment ${status}`, 'success');
      load();
    } catch (err) {
      showToast('Unable to update appointment', 'error');
    }
  };

  if (loading) return <LoadingSpinner label="Loading appointments..." />;

  if (!appointments.length) {
    return <div className="glass-card p-10 text-center text-text-dim">No appointments scheduled yet.</div>;
  }

  return (
    <div className="glass-card p-0 overflow-hidden">
      <table className="responsive-table w-full text-sm">
        <thead>
          <tr className="text-left text-text-dim text-xs">
            <th className="px-5 py-3">User</th>
            <th className="px-5 py-3">Service</th>
            <th className="px-5 py-3">Date</th>
            <th className="px-5 py-3">Time Slot</th>
            <th className="px-5 py-3">Status</th>
            <th className="px-5 py-3">Actions</th>
          </tr>
        </thead>
        <tbody>
          {appointments.map((a) => (
            <tr key={a._id} className="border-t border-white/5 hover:bg-white/[0.02]">
              <td data-label="User" className="px-5 py-3 text-text-muted">{a.user?.name}</td>
              <td data-label="Service" className="px-5 py-3 text-text-muted">{a.service?.name}</td>
              <td data-label="Date" className="px-5 py-3 text-text-muted">{a.date}</td>
              <td data-label="Time" className="px-5 py-3 text-text-muted">{a.timeSlot}</td>
              <td data-label="Status" className="px-5 py-3">
                <span className={`text-xs px-2.5 py-1 rounded-full font-medium ${statusColors[a.status] || ''}`}>{a.status}</span>
              </td>
              <td data-label="Actions" className="px-5 py-3">
                <div className="flex gap-1.5 flex-wrap text-xs">
                  <button onClick={() => updateStatus(a._id, 'confirmed')} className="btn-outline px-2.5 py-1 rounded-lg">Confirm</button>
                  <button onClick={() => updateStatus(a._id, 'completed')} className="btn-outline px-2.5 py-1 rounded-lg">Complete</button>
                  <button onClick={() => updateStatus(a._id, 'no-show')} className="btn-outline px-2.5 py-1 rounded-lg">No-Show</button>
                  <button onClick={() => updateStatus(a._id, 'cancelled')} className="btn-outline px-2.5 py-1 rounded-lg text-state-danger border-state-danger/30">Cancel</button>
                </div>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
};

export default AppointmentManagement;
