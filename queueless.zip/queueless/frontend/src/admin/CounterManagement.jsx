import React, { useEffect, useState } from 'react';
import { Plus, UserCog, Power } from 'lucide-react';
import GlassCard from '../components/GlassCard';
import Modal from '../components/Modal';
import LoadingSpinner from '../components/LoadingSpinner';
import { getCountersApi, createCounterApi, updateCounterApi } from '../services/adminApi';
import { getServicesApi } from '../services/serviceApi';
import { getUsersApi } from '../services/adminApi';
import { useToast } from '../components/Toast';

const CounterManagement = () => {
  const [counters, setCounters] = useState([]);
  const [services, setServices] = useState([]);
  const [staff, setStaff] = useState([]);
  const [loading, setLoading] = useState(true);
  const [createOpen, setCreateOpen] = useState(false);
  const [assignTarget, setAssignTarget] = useState(null);
  const [form, setForm] = useState({ counterNumber: '', service: '' });
  const [assignStaffId, setAssignStaffId] = useState('');
  const { showToast } = useToast();

  const load = async () => {
    try {
      const [countersRes, servicesRes, usersRes] = await Promise.all([
        getCountersApi(),
        getServicesApi(),
        getUsersApi()
      ]);
      setCounters(countersRes.data.counters);
      setServices(servicesRes.data.services);
      setStaff(usersRes.data.users.filter((u) => u.role === 'staff'));
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    load();
  }, []);

  const handleCreate = async () => {
    if (!form.counterNumber || !form.service) {
      showToast('Please fill in all fields', 'warning');
      return;
    }
    try {
      await createCounterApi({ counterNumber: Number(form.counterNumber), service: form.service });
      showToast('Counter created', 'success');
      setCreateOpen(false);
      setForm({ counterNumber: '', service: '' });
      load();
    } catch (err) {
      showToast(err.response?.data?.message || 'Unable to create counter', 'error');
    }
  };

  const handleAssign = async () => {
    try {
      await updateCounterApi(assignTarget._id, { staff: assignStaffId || null });
      showToast('Staff assignment updated', 'success');
      setAssignTarget(null);
      load();
    } catch (err) {
      showToast('Unable to assign staff', 'error');
    }
  };

  const toggleStatus = async (counter) => {
    try {
      await updateCounterApi(counter._id, { status: counter.status === 'active' ? 'inactive' : 'active' });
      showToast(`Counter ${counter.counterNumber} ${counter.status === 'active' ? 'disabled' : 'enabled'}`, 'success');
      load();
    } catch (err) {
      showToast('Unable to update counter', 'error');
    }
  };

  if (loading) return <LoadingSpinner label="Loading counters..." />;

  return (
    <div className="flex flex-col gap-6">
      <div className="flex justify-end">
        <button onClick={() => setCreateOpen(true)} className="btn-primary flex items-center gap-2 px-4 py-2 rounded-lg text-sm">
          <Plus size={16} /> Create Counter
        </button>
      </div>

      <div className="grid md:grid-cols-3 gap-6 grid-cards">
        {counters.map((c) => (
          <GlassCard key={c._id} hover className="animate-slide-up">
            <div className="flex items-center justify-between mb-3">
              <h3 className="font-semibold text-text-primary">Counter {c.counterNumber}</h3>
              <span className={`text-xs px-2.5 py-1 rounded-full font-medium ${c.status === 'active' ? 'bg-state-success/15 text-state-success' : 'bg-state-danger/15 text-state-danger'}`}>
                {c.status}
              </span>
            </div>
            <p className="text-sm text-text-muted mb-1">Service: {c.service?.name}</p>
            <p className="text-sm text-text-muted mb-1">Operator: {c.staff?.name || 'Unassigned'}</p>
            <p className="text-sm text-text-muted mb-4">Serving: {c.currentToken ? `#${c.currentToken.tokenNumber}` : '—'}</p>
            <div className="flex gap-2">
              <button
                onClick={() => { setAssignTarget(c); setAssignStaffId(c.staff?._id || ''); }}
                className="btn-outline flex-1 flex items-center justify-center gap-1.5 py-2 rounded-lg text-xs"
              >
                <UserCog size={13} /> Assign
              </button>
              <button
                onClick={() => toggleStatus(c)}
                className="btn-outline flex-1 flex items-center justify-center gap-1.5 py-2 rounded-lg text-xs"
              >
                <Power size={13} /> {c.status === 'active' ? 'Disable' : 'Enable'}
              </button>
            </div>
          </GlassCard>
        ))}
      </div>

      <Modal open={createOpen} onClose={() => setCreateOpen(false)} title="Create Counter">
        <div className="flex flex-col gap-4">
          <input
            type="number"
            placeholder="Counter number"
            value={form.counterNumber}
            onChange={(e) => setForm((f) => ({ ...f, counterNumber: e.target.value }))}
            className="glass-input w-full px-4 py-2.5 text-sm"
          />
          <select
            value={form.service}
            onChange={(e) => setForm((f) => ({ ...f, service: e.target.value }))}
            className="glass-input w-full px-4 py-2.5 text-sm"
          >
            <option value="">Select service</option>
            {services.map((s) => (
              <option key={s._id} value={s._id}>{s.name}</option>
            ))}
          </select>
          <button onClick={handleCreate} className="btn-primary rounded-xl py-2.5 text-sm font-semibold">
            Create Counter
          </button>
        </div>
      </Modal>

      <Modal open={!!assignTarget} onClose={() => setAssignTarget(null)} title={`Assign Staff — Counter ${assignTarget?.counterNumber}`}>
        <div className="flex flex-col gap-4">
          <select
            value={assignStaffId}
            onChange={(e) => setAssignStaffId(e.target.value)}
            className="glass-input w-full px-4 py-2.5 text-sm"
          >
            <option value="">Unassigned</option>
            {staff.map((s) => (
              <option key={s._id} value={s._id}>{s.name}</option>
            ))}
          </select>
          <button onClick={handleAssign} className="btn-primary rounded-xl py-2.5 text-sm font-semibold">
            Save Assignment
          </button>
        </div>
      </Modal>
    </div>
  );
};

export default CounterManagement;
