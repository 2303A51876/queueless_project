import React, { useEffect, useState } from 'react';
import { Plus, Pencil, Trash2, Pause, Play } from 'lucide-react';
import GlassCard from '../components/GlassCard';
import Modal from '../components/Modal';
import ConfirmDialog from '../components/ConfirmDialog';
import LoadingSpinner from '../components/LoadingSpinner';
import {
  getServicesApi,
  createServiceApi,
  updateServiceApi,
  deleteServiceApi,
  pauseServiceApi,
  resumeServiceApi
} from '../services/serviceApi';
import { useToast } from '../components/Toast';

const emptyForm = {
  name: '',
  description: '',
  averageServiceTime: 10,
  dailyMaximum: 100,
  capacity: 20,
  openTime: '09:00',
  closeTime: '17:00'
};

const ServicesManagement = () => {
  const [services, setServices] = useState([]);
  const [loading, setLoading] = useState(true);
  const [modalOpen, setModalOpen] = useState(false);
  const [editing, setEditing] = useState(null);
  const [form, setForm] = useState(emptyForm);
  const [deleteTarget, setDeleteTarget] = useState(null);
  const { showToast } = useToast();

  const load = async () => {
    try {
      const { data } = await getServicesApi();
      setServices(data.services);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    load();
  }, []);

  const openCreate = () => {
    setEditing(null);
    setForm(emptyForm);
    setModalOpen(true);
  };

  const openEdit = (s) => {
    setEditing(s);
    setForm({
      name: s.name,
      description: s.description,
      averageServiceTime: s.averageServiceTime,
      dailyMaximum: s.dailyMaximum,
      capacity: s.capacity,
      openTime: s.operatingHours?.open || '09:00',
      closeTime: s.operatingHours?.close || '17:00'
    });
    setModalOpen(true);
  };

  const handleSave = async () => {
    if (!form.name.trim()) {
      showToast('Service name is required', 'warning');
      return;
    }
    const payload = {
      name: form.name,
      description: form.description,
      averageServiceTime: Number(form.averageServiceTime),
      dailyMaximum: Number(form.dailyMaximum),
      capacity: Number(form.capacity),
      operatingHours: { open: form.openTime, close: form.closeTime }
    };
    try {
      if (editing) {
        await updateServiceApi(editing._id, payload);
        showToast('Service updated', 'success');
      } else {
        await createServiceApi(payload);
        showToast('Service created', 'success');
      }
      setModalOpen(false);
      load();
    } catch (err) {
      showToast(err.response?.data?.message || 'Unable to save service', 'error');
    }
  };

  const handleDelete = async () => {
    try {
      await deleteServiceApi(deleteTarget._id);
      showToast('Service deleted', 'success');
      load();
    } catch (err) {
      showToast('Unable to delete service', 'error');
    }
  };

  const togglePause = async (s) => {
    try {
      if (s.emergencyPause) {
        await resumeServiceApi(s._id);
      } else {
        await pauseServiceApi(s._id);
      }
      load();
    } catch (err) {
      showToast('Unable to update service status', 'error');
    }
  };

  if (loading) return <LoadingSpinner label="Loading services..." />;

  return (
    <div className="flex flex-col gap-6">
      <div className="flex justify-end">
        <button onClick={openCreate} className="btn-primary flex items-center gap-2 px-4 py-2 rounded-lg text-sm">
          <Plus size={16} /> New Service
        </button>
      </div>

      <div className="grid md:grid-cols-2 xl:grid-cols-3 gap-6 grid-cards">
        {services.map((s) => (
          <GlassCard key={s._id} hover className="animate-slide-up flex flex-col gap-3">
            <div className="flex items-center justify-between">
              <h3 className="font-semibold text-text-primary">{s.name}</h3>
              <span className={`text-xs px-2.5 py-1 rounded-full font-medium ${s.emergencyPause ? 'bg-state-warning/15 text-state-warning' : 'bg-state-success/15 text-state-success'}`}>
                {s.emergencyPause ? 'Paused' : 'Active'}
              </span>
            </div>
            <p className="text-sm text-text-dim">{s.description}</p>
            <div className="text-xs text-text-muted grid grid-cols-2 gap-2">
              <span>Avg time: {s.averageServiceTime}m</span>
              <span>Capacity: {s.capacity}</span>
              <span>Daily max: {s.dailyMaximum}</span>
              <span>{s.operatingHours?.open}–{s.operatingHours?.close}</span>
            </div>
            <div className="flex gap-2 mt-2">
              <button onClick={() => openEdit(s)} className="btn-outline flex-1 flex items-center justify-center gap-1.5 py-2 rounded-lg text-xs">
                <Pencil size={13} /> Edit
              </button>
              <button onClick={() => togglePause(s)} className="btn-outline flex-1 flex items-center justify-center gap-1.5 py-2 rounded-lg text-xs">
                {s.emergencyPause ? <Play size={13} /> : <Pause size={13} />} {s.emergencyPause ? 'Resume' : 'Pause'}
              </button>
              <button onClick={() => setDeleteTarget(s)} className="btn-outline p-2 rounded-lg text-state-danger border-state-danger/30 hover:bg-state-danger/10">
                <Trash2 size={13} />
              </button>
            </div>
          </GlassCard>
        ))}
      </div>

      <Modal open={modalOpen} onClose={() => setModalOpen(false)} title={editing ? 'Edit Service' : 'New Service'}>
        <div className="flex flex-col gap-3">
          <input placeholder="Name" value={form.name} onChange={(e) => setForm((f) => ({ ...f, name: e.target.value }))} className="glass-input px-4 py-2.5 text-sm" />
          <textarea placeholder="Description" value={form.description} onChange={(e) => setForm((f) => ({ ...f, description: e.target.value }))} className="glass-input px-4 py-2.5 text-sm h-20 resize-none" />
          <div className="grid grid-cols-2 gap-3">
            <input type="number" placeholder="Avg service time (min)" value={form.averageServiceTime} onChange={(e) => setForm((f) => ({ ...f, averageServiceTime: e.target.value }))} className="glass-input px-4 py-2.5 text-sm" />
            <input type="number" placeholder="Capacity" value={form.capacity} onChange={(e) => setForm((f) => ({ ...f, capacity: e.target.value }))} className="glass-input px-4 py-2.5 text-sm" />
            <input type="number" placeholder="Daily maximum" value={form.dailyMaximum} onChange={(e) => setForm((f) => ({ ...f, dailyMaximum: e.target.value }))} className="glass-input px-4 py-2.5 text-sm" />
            <div className="flex gap-2">
              <input type="time" value={form.openTime} onChange={(e) => setForm((f) => ({ ...f, openTime: e.target.value }))} className="glass-input px-2 py-2.5 text-sm w-full" />
              <input type="time" value={form.closeTime} onChange={(e) => setForm((f) => ({ ...f, closeTime: e.target.value }))} className="glass-input px-2 py-2.5 text-sm w-full" />
            </div>
          </div>
          <button onClick={handleSave} className="btn-primary rounded-xl py-2.5 text-sm font-semibold mt-2">
            {editing ? 'Save Changes' : 'Create Service'}
          </button>
        </div>
      </Modal>

      <ConfirmDialog
        open={!!deleteTarget}
        onClose={() => setDeleteTarget(null)}
        onConfirm={handleDelete}
        title="Delete Service"
        description={`Are you sure you want to delete "${deleteTarget?.name}"? This cannot be undone.`}
        confirmLabel="Delete"
        danger
      />
    </div>
  );
};

export default ServicesManagement;
