import React, { useEffect, useState } from 'react';
import { Bar, Doughnut } from 'react-chartjs-2';
import {
  Chart as ChartJS,
  CategoryScale,
  LinearScale,
  BarElement,
  ArcElement,
  Tooltip,
  Legend
} from 'chart.js';
import GlassCard from '../components/GlassCard';
import LoadingSpinner from '../components/LoadingSpinner';
import { getAnalyticsApi, getAuditLogsApi } from '../services/adminApi';

ChartJS.register(CategoryScale, LinearScale, BarElement, ArcElement, Tooltip, Legend);

const chartTextColor = '#94A3B8';
const gridColor = 'rgba(255,255,255,0.06)';

const AnalyticsLogs = () => {
  const [stats, setStats] = useState(null);
  const [logs, setLogs] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    Promise.all([getAnalyticsApi(), getAuditLogsApi()])
      .then(([a, l]) => {
        setStats(a.data);
        setLogs(l.data.logs);
      })
      .finally(() => setLoading(false));
  }, []);

  if (loading || !stats) return <LoadingSpinner label="Loading analytics..." />;

  const barData = {
    labels: stats.statusByService.map((s) => s.service),
    datasets: [
      { label: 'Waiting', data: stats.statusByService.map((s) => s.waiting), backgroundColor: '#3B82F6' },
      { label: 'Serving', data: stats.statusByService.map((s) => s.serving), backgroundColor: '#F59E0B' },
      { label: 'Completed', data: stats.statusByService.map((s) => s.completed), backgroundColor: '#22C55E' },
      { label: 'Cancelled', data: stats.statusByService.map((s) => s.cancelled), backgroundColor: '#EC4899' }
    ]
  };

  const barOptions = {
    responsive: true,
    plugins: { legend: { labels: { color: chartTextColor } }, title: { display: false } },
    scales: {
      x: { ticks: { color: chartTextColor }, grid: { color: gridColor } },
      y: { ticks: { color: chartTextColor }, grid: { color: gridColor } }
    }
  };

  const doughnutData = {
    labels: ['Active', 'Completed'],
    datasets: [
      {
        data: [stats.activeVsCompleted.active, stats.activeVsCompleted.completed],
        backgroundColor: ['#2563EB', '#BE185D'],
        borderWidth: 0
      }
    ]
  };

  const doughnutOptions = {
    responsive: true,
    plugins: { legend: { labels: { color: chartTextColor }, position: 'bottom' } }
  };

  const heatmapByService = {};
  stats.heatmap.forEach((h) => {
    if (!heatmapByService[h.service]) heatmapByService[h.service] = Array(24).fill(0);
    heatmapByService[h.service][h.hour] = h.count;
  });
  const maxCount = Math.max(1, ...stats.heatmap.map((h) => h.count));

  return (
    <div className="flex flex-col gap-8">
      <div className="grid lg:grid-cols-2 gap-6">
        <GlassCard className="animate-slide-up">
          <h3 className="font-semibold text-text-primary mb-4">Queue Status by Service</h3>
          <Bar data={barData} options={barOptions} />
        </GlassCard>
        <GlassCard className="animate-slide-up flex flex-col items-center">
          <h3 className="font-semibold text-text-primary mb-4 self-start">Active vs Completed</h3>
          <div className="max-w-xs">
            <Doughnut data={doughnutData} options={doughnutOptions} />
          </div>
        </GlassCard>
      </div>

      <GlassCard className="animate-slide-up overflow-x-auto">
        <h3 className="font-semibold text-text-primary mb-4">Peak-Hour Heatmap</h3>
        <div className="min-w-[700px]">
          {Object.entries(heatmapByService).map(([service, hours]) => (
            <div key={service} className="flex items-center gap-2 mb-2">
              <span className="w-32 text-xs text-text-dim shrink-0">{service}</span>
              <div className="flex gap-1">
                {hours.map((count, hour) => (
                  <div
                    key={hour}
                    title={`${service} · ${hour}:00 · ${count} joined`}
                    className="w-6 h-6 rounded"
                    style={{
                      background: `rgba(236, 72, 153, ${Math.min(0.15 + (count / maxCount) * 0.85, 1)})`
                    }}
                  />
                ))}
              </div>
            </div>
          ))}
          <div className="flex gap-1 ml-[8.5rem] mt-1">
            {Array.from({ length: 24 }).map((_, h) => (
              <span key={h} className="w-6 text-[9px] text-text-dim text-center">{h}</span>
            ))}
          </div>
        </div>
      </GlassCard>

      <GlassCard className="animate-slide-up">
        <h3 className="font-semibold text-text-primary mb-4">Audit Logs</h3>
        <div className="flex flex-col gap-2 max-h-96 overflow-y-auto">
          {logs.map((log) => (
            <div key={log._id} className="flex items-center justify-between text-sm border-b border-white/5 py-2 last:border-0">
              <span className="text-text-muted">
                <span className="text-text-primary font-medium">{log.actorName}</span> — {log.action}
              </span>
              <span className="text-xs text-text-dim shrink-0 ml-4">{new Date(log.timestamp).toLocaleString()}</span>
            </div>
          ))}
        </div>
      </GlassCard>
    </div>
  );
};

export default AnalyticsLogs;
