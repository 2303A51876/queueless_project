import React, { useEffect, useState } from 'react';
import { Users, Radar, CheckCircle2, Clock3, Pause, Play, Megaphone, AlertOctagon } from 'lucide-react';
import GlassCard from '../components/GlassCard';
import LoadingSpinner from '../components/LoadingSpinner';
import Modal from '../components/Modal';
import ConfirmDialog from '../components/ConfirmDialog';
import { getAnalyticsApi } from '../services/adminApi';
import { getServicesApi, pauseServiceApi, resumeServiceApi } from '../services/serviceApi';
import useAuth from '../hooks/useAuth';
import useSocket from '../hooks/useSocket';
import { useToast } from '../components/Toast';

const KpiCard = ({ icon: Icon, label, value, color }) => (
  <GlassCard className="animate-slide-up flex items-center gap-4">
    <div className={`p-3 rounded-xl ${color}`}>
      <Icon size={20} className="text-white" />
    </div>
    <div>
      <p className="text-xs text-text-dim">{label}</p>
      <p className="text-2xl font-extrabold text-text-primary">{value}</p>
    </div>
  </GlassCard>
);

const Overview = () => {
  const [stats, setStats] = useState(null);
  const [services, setServices] = useState([]);
  const [loading, setLoading] = useState(true);
  const [pauseTarget, setPauseTarget] = useState(null);
  const [announceOpen, setAnnounceOpen] = useState(false);
  const [message, setMessage] = useState('');
  const { user } = useAuth();
  const { socket } = useSocket();
  const { showToast } = useToast();

  const load = async () => {
    try {
      const [analyticsRes, servicesRes] = await Promise.all([getAnalyticsApi(), getServicesApi()]);
      setStats(analyticsRes.data);
      setServices(servicesRes.data.services);
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    load();
  }, []);

  const togglePause = async () => {
    const s = pauseTarget;
    try {
      if (s.emergencyPause) {
        await resumeServiceApi(s._id);
        showToast(`Resumed queue for ${s.name}`, 'success');
      } else {
        await pauseServiceApi(s._id);
        showToast(`Paused queue for ${s.name}`, 'warning');
      }
      load();
    } catch (err) {
      showToast('Unable to update queue status', 'error');
    }
  };

  const sendAnnouncement = () => {
    if (!message.trim() || !socket) return;
    socket.emit('sendAnnouncement', {
      message,
      type: 'delay',
      userId: user?.id,
      userName: user?.name
    });
    showToast('Announcement broadcast to all clients', 'success');
    setMessage('');
    setAnnounceOpen(false);
  };

  if (loading || !stats) return <LoadingSpinner label="Loading overview..." />;

  return (
    <div className="flex flex-col gap-8">
      <div className="grid md:grid-cols-4 gap-4 grid-cards">
        <KpiCard icon={Users} label="Total Users" value={stats.totalUsers} color="bg-blue-electric" />
        <KpiCard icon={Radar} label="Active Queues" value={stats.activeQueues} color="bg-pink-accent" />
        <KpiCard icon={CheckCircle2} label="Served Today" value={stats.servedToday} color="bg-state-success" />
        <KpiCard icon={Clock3} label="Avg Handling Time" value={`${stats.avgHandlingTime}m`} color="bg-state-warning" />
      </div>

      <GlassCard pink className="animate-slide-up">
        <div className="flex items-center justify-between mb-4">
          <h3 className="font-semibold text-text-primary flex items-center gap-2">
            <AlertOctagon size={18} className="text-pink-accent" /> Emergency Controls
          </h3>
          <button
            onClick={() => setAnnounceOpen(true)}
            className="btn-accent flex items-center gap-2 px-4 py-2 rounded-lg text-sm"
          >
            <Megaphone size={15} /> Broadcast Message
          </button>
        </div>
        <div className="grid md:grid-cols-3 gap-4">
          {services.map((s) => (
            <div key={s._id} className="glass-card p-4 flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-text-primary">{s.name}</p>
                <p className={`text-xs mt-0.5 ${s.emergencyPause ? 'text-state-warning' : 'text-state-success'}`}>
                  {s.emergencyPause ? 'Paused' : 'Active'}
                </p>
              </div>
              <button
                onClick={() => setPauseTarget(s)}
                className="btn-outline p-2 rounded-lg"
                title={s.emergencyPause ? 'Resume Queue' : 'Pause Queue'}
              >
                {s.emergencyPause ? <Play size={15} /> : <Pause size={15} />}
              </button>
            </div>
          ))}
        </div>
      </GlassCard>

      <ConfirmDialog
        open={!!pauseTarget}
        onClose={() => setPauseTarget(null)}
        onConfirm={togglePause}
        title={pauseTarget?.emergencyPause ? 'Resume Queue' : 'Pause Queue'}
        description={`Are you sure you want to ${pauseTarget?.emergencyPause ? 'resume' : 'pause'} the queue for "${pauseTarget?.name}"?`}
        confirmLabel={pauseTarget?.emergencyPause ? 'Resume' : 'Pause'}
        danger={!pauseTarget?.emergencyPause}
      />

      <Modal open={announceOpen} onClose={() => setAnnounceOpen(false)} title="Broadcast Announcement">
        <div className="flex flex-col gap-4">
          <textarea
            value={message}
            onChange={(e) => setMessage(e.target.value)}
            placeholder="e.g. All queues are experiencing a 15 minute delay"
            className="glass-input w-full px-4 py-2.5 text-sm h-24 resize-none"
          />
          <button onClick={sendAnnouncement} className="btn-accent rounded-xl py-2.5 text-sm font-semibold">
            Send to All Connected Clients
          </button>
        </div>
      </Modal>
    </div>
  );
};

export default Overview;
