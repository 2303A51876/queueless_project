import React, { useEffect, useState, useCallback } from 'react';
import { PhoneCall, CheckCircle2, UserX, RotateCcw, XCircle } from 'lucide-react';
import GlassCard from '../components/GlassCard';
import LoadingSpinner from '../components/LoadingSpinner';
import ConfirmDialog from '../components/ConfirmDialog';
import {
  listAllTokensApi,
  callNextTokenApi,
  completeTokenApi,
  markNoShowApi,
  recallTokenApi,
  adminCancelTokenApi
} from '../services/queueApi';
import { getServicesApi } from '../services/serviceApi';
import { getCountersApi } from '../services/adminApi';
import useSocket from '../hooks/useSocket';
import { useToast } from '../components/Toast';

const statusColors = {
  waiting: 'text-blue-bright bg-blue-electric/15',
  called: 'text-state-warning bg-state-warning/15',
  serving: 'text-state-success bg-state-success/15',
  completed: 'text-text-dim bg-white/5',
  cancelled: 'text-state-danger bg-state-danger/15',
  'no-show': 'text-state-danger bg-state-danger/15',
  transferred: 'text-pink-accent bg-pink-accent/15'
};

const QueueControl = () => {
  const [tokens, setTokens] = useState([]);
  const [services, setServices] = useState([]);
  const [counters, setCounters] = useState([]);
  const [loading, setLoading] = useState(true);
  const [filters, setFilters] = useState({ service: '', status: '', priority: '' });
  const [selectedService, setSelectedService] = useState('');
  const [selectedCounter, setSelectedCounter] = useState('');
  const [cancelTarget, setCancelTarget] = useState(null);
  const { socket } = useSocket();
  const { showToast } = useToast();

  const load = useCallback(async () => {
    try {
      const cleanFilters = Object.fromEntries(Object.entries(filters).filter(([, v]) => v));
      const [tokensRes, servicesRes, countersRes] = await Promise.all([
        listAllTokensApi(cleanFilters),
        getServicesApi(),
        getCountersApi()
      ]);
      setTokens(tokensRes.data.tokens);
      setServices(servicesRes.data.services);
      setCounters(countersRes.data.counters);
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  }, [filters]);

  useEffect(() => {
    load();
  }, [load]);

  useEffect(() => {
    if (!socket) return;
    const handler = () => load();
    socket.on('queueUpdated', handler);
    socket.on('nextTokenCalled', handler);
    socket.on('tokenCompleted', handler);
    return () => {
      socket.off('queueUpdated', handler);
      socket.off('nextTokenCalled', handler);
      socket.off('tokenCompleted', handler);
    };
  }, [socket, load]);

  const callNext = async () => {
    if (!selectedService || !selectedCounter) {
      showToast('Select a service and counter first', 'warning');
      return;
    }
    try {
      const { data } = await callNextTokenApi(selectedService, selectedCounter);
      showToast(`Called Token #${data.token.tokenNumber}`, 'success');
      load();
    } catch (err) {
      showToast(err.response?.data?.message || 'No waiting tokens for this service', 'error');
    }
  };

  const doAction = async (fn, successMsg, id) => {
    try {
      await fn(id);
      showToast(successMsg, 'success');
      load();
    } catch (err) {
      showToast(err.response?.data?.message || 'Action failed', 'error');
    }
  };

  const relevantCounters = counters.filter((c) => c.service?._id === selectedService && c.status === 'active');

  if (loading) return <LoadingSpinner label="Loading queue control..." />;

  return (
    <div className="flex flex-col gap-6">
      <GlassCard pink className="animate-slide-up flex flex-col md:flex-row gap-3 items-stretch md:items-end">
        <div className="flex-1">
          <label className="text-xs text-text-dim mb-1 block">Service</label>
          <select value={selectedService} onChange={(e) => { setSelectedService(e.target.value); setSelectedCounter(''); }} className="glass-input w-full px-4 py-2.5 text-sm">
            <option value="">Select service</option>
            {services.map((s) => <option key={s._id} value={s._id}>{s.name}</option>)}
          </select>
        </div>
        <div className="flex-1">
          <label className="text-xs text-text-dim mb-1 block">Counter</label>
          <select value={selectedCounter} onChange={(e) => setSelectedCounter(e.target.value)} className="glass-input w-full px-4 py-2.5 text-sm">
            <option value="">Select counter</option>
            {relevantCounters.map((c) => <option key={c._id} value={c._id}>Counter {c.counterNumber}</option>)}
          </select>
        </div>
        <button onClick={callNext} className="btn-accent flex items-center justify-center gap-2 px-5 py-2.5 rounded-lg text-sm font-semibold">
          <PhoneCall size={15} /> Call Next Token
        </button>
      </GlassCard>

      <div className="flex flex-wrap gap-3">
        <select value={filters.service} onChange={(e) => setFilters((f) => ({ ...f, service: e.target.value }))} className="glass-input px-3 py-2 text-xs">
          <option value="">All Services</option>
          {services.map((s) => <option key={s._id} value={s._id}>{s.name}</option>)}
        </select>
        <select value={filters.status} onChange={(e) => setFilters((f) => ({ ...f, status: e.target.value }))} className="glass-input px-3 py-2 text-xs">
          <option value="">All Statuses</option>
          {['waiting', 'called', 'serving', 'completed', 'cancelled', 'no-show', 'transferred'].map((s) => (
            <option key={s} value={s}>{s}</option>
          ))}
        </select>
        <select value={filters.priority} onChange={(e) => setFilters((f) => ({ ...f, priority: e.target.value }))} className="glass-input px-3 py-2 text-xs">
          <option value="">All Priorities</option>
          <option value="none">None</option>
          <option value="senior">Senior</option>
          <option value="disability">Disability</option>
        </select>
      </div>

      <div className="glass-card p-0 overflow-hidden">
        <table className="responsive-table w-full text-sm">
          <thead>
            <tr className="text-left text-text-dim text-xs">
              <th className="px-4 py-3">Token #</th>
              <th className="px-4 py-3">User</th>
              <th className="px-4 py-3">Priority</th>
              <th className="px-4 py-3">Status</th>
              <th className="px-4 py-3">Counter</th>
              <th className="px-4 py-3">Actions</th>
            </tr>
          </thead>
          <tbody>
            {tokens.map((t) => (
              <tr key={t._id} className="border-t border-white/5 hover:bg-white/[0.02]">
                <td data-label="Token #" className="px-4 py-3 text-text-primary font-medium">#{t.tokenNumber}</td>
                <td data-label="User" className="px-4 py-3 text-text-muted">
                  {t.user?.name}<br /><span className="text-xs text-text-dim">{t.user?.email}</span>
                </td>
                <td data-label="Priority" className="px-4 py-3 text-text-muted capitalize">{t.priority}</td>
                <td data-label="Status" className="px-4 py-3">
                  <span className={`text-xs px-2.5 py-1 rounded-full font-medium ${statusColors[t.status] || ''}`}>{t.status}</span>
                </td>
                <td data-label="Counter" className="px-4 py-3 text-text-muted">{t.counter ? `Counter ${t.counter.counterNumber}` : '—'}</td>
                <td data-label="Actions" className="px-4 py-3">
                  <div className="flex gap-1.5 flex-wrap">
                    {['called', 'serving'].includes(t.status) && (
                      <>
                        <button onClick={() => doAction(completeTokenApi, `Token #${t.tokenNumber} completed`, t._id)} className="p-1.5 rounded-lg btn-outline" title="Mark Complete">
                          <CheckCircle2 size={14} />
                        </button>
                        <button onClick={() => doAction(markNoShowApi, `Token #${t.tokenNumber} marked no-show`, t._id)} className="p-1.5 rounded-lg btn-outline" title="Mark No-Show">
                          <UserX size={14} />
                        </button>
                        <button onClick={() => doAction(recallTokenApi, `Re-called Token #${t.tokenNumber}`, t._id)} className="p-1.5 rounded-lg btn-outline" title="Re-call">
                          <RotateCcw size={14} />
                        </button>
                      </>
                    )}
                    {['waiting', 'called'].includes(t.status) && (
                      <button onClick={() => setCancelTarget(t)} className="p-1.5 rounded-lg btn-outline text-state-danger border-state-danger/30" title="Cancel">
                        <XCircle size={14} />
                      </button>
                    )}
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      <ConfirmDialog
        open={!!cancelTarget}
        onClose={() => setCancelTarget(null)}
        onConfirm={() => doAction(adminCancelTokenApi, `Token #${cancelTarget.tokenNumber} cancelled`, cancelTarget._id)}
        title="Cancel Token"
        description={`Cancel Token #${cancelTarget?.tokenNumber}?`}
        confirmLabel="Cancel Token"
        danger
      />
    </div>
  );
};

export default QueueControl;
