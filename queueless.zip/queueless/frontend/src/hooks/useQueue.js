import { useEffect, useState, useCallback } from 'react';
import useSocket from './useSocket';
import { getServicesApi } from '../services/serviceApi';

/**
 * Loads services and keeps them live-synced via Socket.io.
 */
const useQueue = () => {
  const { socket } = useSocket();
  const [services, setServices] = useState([]);
  const [loading, setLoading] = useState(true);

  const refresh = useCallback(async () => {
    try {
      const { data } = await getServicesApi();
      setServices(data.services);
    } catch (err) {
      console.error('Failed to load services', err);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    refresh();
  }, [refresh]);

  useEffect(() => {
    if (!socket) return;
    const handler = () => refresh();
    socket.on('queueUpdated', handler);
    socket.on('nextTokenCalled', handler);
    socket.on('tokenCompleted', handler);
    return () => {
      socket.off('queueUpdated', handler);
      socket.off('nextTokenCalled', handler);
      socket.off('tokenCompleted', handler);
    };
  }, [socket, refresh]);

  return { services, loading, refresh };
};

export default useQueue;
