import React from 'react';
import { Routes, Route } from 'react-router-dom';
import { AuthProvider } from './context/AuthContext';
import { SocketProvider } from './context/SocketContext';
import { ToastProvider } from './components/Toast';
import ProtectedRoute from './components/ProtectedRoute';

import Navbar from './components/Navbar';
import Footer from './components/Footer';

import Landing from './pages/Landing';
import Login from './pages/Login';
import Register from './pages/Register';
import Dashboard from './pages/Dashboard';
import AdminDashboard from './pages/AdminDashboard';
import Display from './pages/Display';

const AppShell = () => {
  const path = window.location.pathname;
  const isKiosk = path === '/display';

  return (
    <>
      <div className="app-background" />
      {!isKiosk && <Navbar />}
      <Routes>
        <Route path="/" element={<Landing />} />
        <Route path="/login" element={<Login />} />
        <Route path="/register" element={<Register />} />
        <Route
          path="/dashboard"
          element={
            <ProtectedRoute>
              <Dashboard />
            </ProtectedRoute>
          }
        />
        <Route
          path="/admin"
          element={
            <ProtectedRoute roles={['admin', 'staff']}>
              <AdminDashboard />
            </ProtectedRoute>
          }
        />
        <Route path="/display" element={<Display />} />
      </Routes>
      {!isKiosk && <Footer />}
    </>
  );
};

const App = () => (
  <AuthProvider>
    <SocketProvider>
      <ToastProvider>
        <AppShell />
      </ToastProvider>
    </SocketProvider>
  </AuthProvider>
);

export default App;
