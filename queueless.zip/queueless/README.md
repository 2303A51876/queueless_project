# Queue Less

A real-time queue &amp; appointment management SaaS platform. Users join live queues or book
appointments and track their position in real time; staff and admins manage counters, services,
and queues from a live control dashboard; a kiosk display mode shows "Now Serving" on a public
screen.

> **Demo project notice:** All seed data uses generic placeholder identities
> (`vasudevadmin@example.com`, `Alex Johnson`, `staff1@example.com`, etc.). No real personal information
> is included anywhere in the codebase or seed data.

---

## Tech Stack

**Frontend:** React 18, Vite, Tailwind CSS, Lucide Icons, Axios, Socket.io-client, Chart.js,
react-chartjs-2, React Router, qrcode.react

**Backend:** Node.js 20+, Express, Socket.io, JWT, bcryptjs, Mongoose, REST APIs, RBAC

**Database:** MongoDB

**DevOps:** Docker, Docker Compose, Render-ready backend, Vercel-ready frontend

---

## Project Structure

```
queueless/
├── backend/         # Express + Socket.io + MongoDB API
├── frontend/        # React + Vite SPA
└── docker-compose.yml
```

See `backend/` and `frontend/` for their internal file layouts (controllers/routes/models on the
backend; pages/components/dashboard/admin on the frontend).

---

## 1. Local Development Setup

### Prerequisites
- Node.js v20+
- MongoDB running locally (or a MongoDB Atlas connection string)
- npm

### Backend

```bash
cd backend
cp .env.example .env      # edit MONGO_URI / JWT_SECRET as needed
npm install
npm run seed               # populates generic demo data (safe to re-run)
npm run dev                 # starts the API on http://localhost:5000
```

### Frontend

```bash
cd frontend
cp .env.example .env
npm install
npm run dev                 # starts the app on http://localhost:5173
```

Visit `http://localhost:5173`. Use the **Demo Credentials** panel on the Login page to auto-fill
an admin, staff, or user account (password for all seeded accounts is `password123`).

---

## 2. Running with Docker Compose

From the project root:

```bash
cp .env.example .env        # set JWT_SECRET
docker compose up --build
```

This starts:
- `mongodb` on port `27017`
- `backend` on port `5000`
- `frontend` (static build served via `serve`) on port `4173`

After the containers are up, seed the database once:

```bash
docker compose exec backend npm run seed
```

> **Note:** Vite inlines `VITE_API_URL` / `VITE_SOCKET_URL` at build time. If you change these,
> set them in the root `.env` **before** running `docker compose up --build` so they're baked into
> the frontend image correctly.

---

## 3. Demo Accounts

| Role  | Email                     | Password      |
|-------|---------------------------|---------------|
| Admin | vasudevadmin@example.com  | password123   |
| Admin | shylasriadmin@example.com | password123   |
| Staff | staff1@example.com        | password123   |
| Staff | staff2@example.com        | password123   |
| Staff | staff3@example.com        | password123   |
| User  | alex.johnson@example.com  | password123   |
| User  | priya.sharma@example.com  | password123   |
| ...   | (10 demo users total, all `@example.com`) | password123 |

---

## 4. Key Routes

**Frontend**
- `/` — Public landing page with live queue preview, service directory, FAQ
- `/login`, `/register` — Authentication
- `/dashboard` — User dashboard (Available Services / My Queue & Appointments / History)
- `/admin` — Admin & staff dashboard (Overview, Counters, Services, Queue Control,
  Appointments, Analytics & Logs) — restricted to `staff` and `admin` roles
- `/display` — Full-screen kiosk / public "Now Serving" display

**Backend REST API** (base `/api`)
```
POST   /auth/register            POST   /auth/login            GET  /auth/me
GET    /services                 POST   /services               PUT  /services/:id        DELETE /services/:id
POST   /queues/join               GET    /queues/my              PUT  /queues/:id/snooze
PUT    /queues/:id/cancel         PUT    /queues/:id/transfer
POST   /queues/admin/next         PUT    /queues/admin/:id/complete
PUT    /queues/admin/:id/no-show  PUT    /queues/admin/:id/recall
GET    /appointments              POST   /appointments           PUT  /appointments/:id
GET    /counters                  POST   /counters               PUT  /counters/:id
GET    /analytics                 GET    /audit-logs
GET    /health
```

**Socket.io events**
`queueUpdated`, `nextTokenCalled`, `tokenCompleted`, `broadcastAnnouncement`, `counterAssigned`

---

## 5. Deployment

### Backend → Render
1. Create a new Web Service pointing at `backend/`.
2. Build command: `npm install`. Start command: `npm start`.
3. Set environment variables: `MONGO_URI`, `JWT_SECRET`, `CLIENT_URL` (your Vercel URL), `PORT`
   (Render sets this automatically).
4. Health check path: `/api/health`.

### Frontend → Vercel
1. Import the `frontend/` directory as the project root.
2. Framework preset: Vite.
3. Set environment variables `VITE_API_URL` and `VITE_SOCKET_URL` to your Render backend URL.
4. Never expose backend secrets (e.g. `JWT_SECRET`) in frontend environment variables.

---

## 6. Security Notes

- Passwords are hashed with bcryptjs; the password field is excluded from query results by
  default (`select: false`) and from API responses.
- JWT-based authentication with role-based middleware (`authMiddleware`, `roleMiddleware`,
  `adminMiddleware`, `staffMiddleware`).
- CORS is restricted to the configured `CLIENT_URL`.
- The `password123` demo password is intentionally used only for seed/demo accounts, as
  explicitly requested for this project; rotate or remove seed accounts before any real
  deployment.

---

## 7. Queue Wait-Time Algorithm

Estimated wait time is computed dynamically from: number of people ahead (accounting for
priority ordering), the service's average handling time, and the number of currently active
counters for that service. Estimates are recalculated whenever a user joins, a token is called
or completed, or a counter's availability changes. See `backend/utils/queueUtils.js`.
