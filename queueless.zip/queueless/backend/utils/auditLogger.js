const AuditLog = require('../models/AuditLog');

const logAction = async ({ actor, actorName, action, entity, entityId, metadata }) => {
  try {
    await AuditLog.create({
      actor: actor || null,
      actorName: actorName || 'System',
      action,
      entity,
      entityId: entityId || null,
      metadata: metadata || {}
    });
  } catch (err) {
    console.error('[AuditLogger] Failed to write audit log:', err.message);
  }
};

module.exports = { logAction };
