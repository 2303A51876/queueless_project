const Token = require('../models/Token');
const Counter = require('../models/Counter');

/**
 * Estimate wait time for a given token based on:
 * - number of people ahead in the waiting line (respecting priority ordering)
 * - average service time of the service
 * - number of active counters assigned to the service
 */
const estimateWaitMinutes = async ({ serviceId, averageServiceTime, priority, joinedAt }) => {
  const activeCounters = await Counter.countDocuments({ service: serviceId, status: 'active' });
  const effectiveCounters = Math.max(activeCounters, 1);

  // People ahead = anyone waiting/called before this token, with priority tokens
  // counted as "ahead" of non-priority tokens regardless of join time.
  const query = { service: serviceId, status: { $in: ['waiting', 'called'] } };
  const waitingTokens = await Token.find(query).sort({ joinedAt: 1 }).lean();

  let peopleAhead = 0;
  for (const t of waitingTokens) {
    if (String(t._id) === undefined) continue;
    const isAheadByPriority = priority === 'none' && t.priority !== 'none';
    const isAheadByTime = new Date(t.joinedAt) < new Date(joinedAt);
    if (isAheadByPriority || (t.priority === priority && isAheadByTime) || (t.priority !== 'none' && priority === 'none')) {
      peopleAhead += 1;
    }
  }

  const estimate = Math.ceil((peopleAhead * averageServiceTime) / effectiveCounters);
  return Math.max(estimate, 0);
};

const nextTokenNumber = (lastTokenNumber) => (lastTokenNumber || 0) + 1;

module.exports = { estimateWaitMinutes, nextTokenNumber };
