/**
 * Generic automated seed script for Queue Less.
 * - Uses only generic demo names/emails (@example.com) — no real personal data.
 * - Safe to run multiple times: checks existing records and skips duplicates.
 */
require('dotenv').config();
const bcrypt = require('bcryptjs');
const mongoose = require('mongoose');
const connectDB = require('./db');

const User = require('../models/User');
const Service = require('../models/Service');
const Counter = require('../models/Counter');
const Token = require('../models/Token');
const Appointment = require('../models/Appointment');

const DEMO_PASSWORD = 'password123';

const demoUsers = [
  { name: 'Vasudev Admin', email: 'vasudevadmin@example.com', role: 'admin' },
  { name: 'Shyla Sri Admin', email: 'shylasriadmin@example.com', role: 'admin' },
  { name: 'Staff One', email: 'staff1@example.com', role: 'staff' },
  { name: 'Staff Two', email: 'staff2@example.com', role: 'staff' },
  { name: 'Staff Three', email: 'staff3@example.com', role: 'staff' },
  { name: 'Alex Johnson', email: 'alex.johnson@example.com', role: 'user' },
  { name: 'Priya Sharma', email: 'priya.sharma@example.com', role: 'user' },
  { name: 'Rahul Mehta', email: 'rahul.mehta@example.com', role: 'user' },
  { name: 'Emma Wilson', email: 'emma.wilson@example.com', role: 'user' },
  { name: 'Daniel Brown', email: 'daniel.brown@example.com', role: 'user' },
  { name: 'Sophia Davis', email: 'sophia.davis@example.com', role: 'user' },
  { name: 'Arjun Patel', email: 'arjun.patel@example.com', role: 'user' },
  { name: 'Olivia Taylor', email: 'olivia.taylor@example.com', role: 'user' },
  { name: 'Noah Anderson', email: 'noah.anderson@example.com', role: 'user' },
  { name: 'Mia Thomas', email: 'mia.thomas@example.com', role: 'user' }
];

const demoServices = [
  {
    name: 'Government Office',
    description: 'General public services, document processing, and civic applications.',
    averageServiceTime: 12,
    dailyMaximum: 150,
    capacity: 20,
    operatingHours: { open: '09:00', close: '17:00' },
    status: 'active',
    emergencyPause: false
  },
  {
    name: 'Bank Service',
    description: 'Account services, deposits, withdrawals, and customer support.',
    averageServiceTime: 8,
    dailyMaximum: 200,
    capacity: 25,
    operatingHours: { open: '09:30', close: '16:30' },
    status: 'active',
    emergencyPause: false
  },
  {
    name: 'Hospital Appointment',
    description: 'Outpatient consultations and scheduled medical appointments.',
    averageServiceTime: 15,
    dailyMaximum: 100,
    capacity: 15,
    operatingHours: { open: '08:00', close: '18:00' },
    status: 'active',
    emergencyPause: false
  }
];

const run = async () => {
  await connectDB();
  console.log('[Seed] Starting generic demo data seed...');

  const salt = await bcrypt.genSalt(10);
  const hashedPassword = await bcrypt.hash(DEMO_PASSWORD, salt);

  const userMap = {};
  for (const u of demoUsers) {
    let existing = await User.findOne({ email: u.email });
    if (!existing) {
      existing = await User.create({
        name: u.name,
        email: u.email,
        password: hashedPassword,
        role: u.role,
        priorityStatus: 'none'
      });
      console.log(`[Seed] Created user: ${u.email} (${u.role})`);
    }
    userMap[u.email] = existing;
  }

  const serviceMap = {};
  for (const s of demoServices) {
    let existing = await Service.findOne({ name: s.name });
    if (!existing) {
      existing = await Service.create(s);
      console.log(`[Seed] Created service: ${s.name}`);
    }
    serviceMap[s.name] = existing;
  }

  // Counters: 2 per service, assigned to staff members round-robin
  const staffUsers = [userMap['staff1@example.com'], userMap['staff2@example.com'], userMap['staff3@example.com']];
  let staffIndex = 0;
  for (const serviceName of Object.keys(serviceMap)) {
    const service = serviceMap[serviceName];
    for (let i = 1; i <= 2; i++) {
      const existing = await Counter.findOne({ service: service._id, counterNumber: i });
      if (!existing) {
        await Counter.create({
          counterNumber: i,
          service: service._id,
          staff: staffUsers[staffIndex % staffUsers.length]._id,
          status: 'active'
        });
        console.log(`[Seed] Created Counter ${i} for ${serviceName}`);
      }
      staffIndex += 1;
    }
  }

  // Demo tokens (queue records) for Government Office to populate live preview
  const govService = serviceMap['Government Office'];
  const existingTokenCount = await Token.countDocuments({ service: govService._id });
  if (existingTokenCount === 0) {
    const demoQueueUsers = [
      userMap['alex.johnson@example.com'],
      userMap['priya.sharma@example.com'],
      userMap['rahul.mehta@example.com']
    ];
    let tokenNumber = govService.lastTokenNumber;
    for (const u of demoQueueUsers) {
      tokenNumber += 1;
      await Token.create({
        tokenNumber,
        user: u._id,
        service: govService._id,
        priority: 'none',
        status: 'waiting',
        joinedAt: new Date(),
        qrPayload: `QUEUELESS:${govService._id}:${tokenNumber}:${Date.now()}`
      });
    }
    govService.lastTokenNumber = tokenNumber;
    govService.currentServingToken = Math.max(tokenNumber - demoQueueUsers.length, 1);
    await govService.save();
    console.log(`[Seed] Created ${demoQueueUsers.length} demo tokens for Government Office`);
  }

  // Demo appointment
  const bankService = serviceMap['Bank Service'];
  const existingAppt = await Appointment.findOne({ service: bankService._id });
  if (!existingAppt) {
    await Appointment.create({
      user: userMap['emma.wilson@example.com']._id,
      service: bankService._id,
      date: new Date(Date.now() + 86400000).toISOString().slice(0, 10),
      timeSlot: '10:30',
      status: 'confirmed'
    });
    console.log('[Seed] Created demo appointment for Bank Service');
  }

  console.log('[Seed] Seed complete.');
  await mongoose.connection.close();
  process.exit(0);
};

run().catch((err) => {
  console.error('[Seed] Error:', err);
  process.exit(1);
});
