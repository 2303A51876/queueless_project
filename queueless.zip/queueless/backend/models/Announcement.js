const mongoose = require('mongoose');

const announcementSchema = new mongoose.Schema(
  {
    message: { type: String, required: true },
    type: { type: String, enum: ['info', 'warning', 'delay'], default: 'info' },
    service: { type: mongoose.Schema.Types.ObjectId, ref: 'Service', default: null },
    createdBy: { type: mongoose.Schema.Types.ObjectId, ref: 'User', default: null }
  },
  { timestamps: true }
);

module.exports = mongoose.model('Announcement', announcementSchema);
