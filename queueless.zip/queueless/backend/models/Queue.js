const mongoose = require('mongoose');

// Represents the live queue state for a service. Individual entries live in
// the Token collection; this document tracks aggregate/service-level state.
const queueSchema = new mongoose.Schema(
  {
    service: { type: mongoose.Schema.Types.ObjectId, ref: 'Service', required: true, unique: true },
    nowServingToken: { type: Number, default: 0 },
    waitingCount: { type: Number, default: 0 },
    isPaused: { type: Boolean, default: false },
    pauseReason: { type: String, default: '' }
  },
  { timestamps: true }
);

module.exports = mongoose.model('Queue', queueSchema);
