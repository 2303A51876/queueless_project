const mongoose = require('mongoose');

const tokenSchema = new mongoose.Schema(
  {
    tokenNumber: { type: Number, required: true },
    user: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
    service: { type: mongoose.Schema.Types.ObjectId, ref: 'Service', required: true },
    priority: { type: String, enum: ['none', 'senior', 'disability'], default: 'none' },
    status: {
      type: String,
      enum: ['waiting', 'called', 'serving', 'completed', 'cancelled', 'no-show', 'transferred'],
      default: 'waiting'
    },
    counter: { type: mongoose.Schema.Types.ObjectId, ref: 'Counter', default: null },
    joinedAt: { type: Date, default: Date.now },
    calledAt: { type: Date, default: null },
    completedAt: { type: Date, default: null },
    snoozeUntil: { type: Date, default: null },
    estimatedWaitMinutes: { type: Number, default: 0 },
    qrPayload: { type: String, default: '' }
  },
  { timestamps: true }
);

tokenSchema.index({ service: 1, status: 1 });
tokenSchema.index({ user: 1, createdAt: -1 });

module.exports = mongoose.model('Token', tokenSchema);
