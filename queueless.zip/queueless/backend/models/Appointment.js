const mongoose = require('mongoose');

const appointmentSchema = new mongoose.Schema(
  {
    user: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
    service: { type: mongoose.Schema.Types.ObjectId, ref: 'Service', required: true },
    date: { type: String, required: true }, // YYYY-MM-DD
    timeSlot: { type: String, required: true }, // e.g. "10:30"
    status: {
      type: String,
      enum: ['pending', 'confirmed', 'rescheduled', 'completed', 'cancelled', 'no-show'],
      default: 'pending'
    },
    token: { type: mongoose.Schema.Types.ObjectId, ref: 'Token', default: null }
  },
  { timestamps: true }
);

appointmentSchema.index({ service: 1, date: 1 });

module.exports = mongoose.model('Appointment', appointmentSchema);
