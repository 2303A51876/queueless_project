const mongoose = require('mongoose');

const counterSchema = new mongoose.Schema(
  {
    counterNumber: { type: Number, required: true },
    staff: { type: mongoose.Schema.Types.ObjectId, ref: 'User', default: null },
    service: { type: mongoose.Schema.Types.ObjectId, ref: 'Service', required: true },
    status: { type: String, enum: ['active', 'inactive'], default: 'active' },
    currentToken: { type: mongoose.Schema.Types.ObjectId, ref: 'Token', default: null }
  },
  { timestamps: true }
);

counterSchema.index({ service: 1, counterNumber: 1 }, { unique: true });

module.exports = mongoose.model('Counter', counterSchema);
