const mongoose = require('mongoose');

const serviceSchema = new mongoose.Schema(
  {
    name: { type: String, required: true, trim: true },
    description: { type: String, default: '' },
    averageServiceTime: { type: Number, default: 10 }, // minutes
    dailyMaximum: { type: Number, default: 200 },
    capacity: { type: Number, default: 20 },
    operatingHours: {
      open: { type: String, default: '09:00' },
      close: { type: String, default: '17:00' }
    },
    status: {
      type: String,
      enum: ['active', 'paused', 'closed'],
      default: 'active'
    },
    emergencyPause: { type: Boolean, default: false },
    currentServingToken: { type: Number, default: 0 },
    lastTokenNumber: { type: Number, default: 0 }
  },
  { timestamps: true }
);

module.exports = mongoose.model('Service', serviceSchema);
