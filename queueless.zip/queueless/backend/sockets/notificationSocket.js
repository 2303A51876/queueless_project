const Announcement = require('../models/Announcement');
const { logAction } = require('../utils/auditLogger');

const registerNotificationSocket = (io, socket) => {
  // Admin/staff can broadcast an announcement to all connected clients
  socket.on('sendAnnouncement', async (payload) => {
    try {
      const { message, type, service, userId, userName } = payload || {};
      if (!message) return;

      const announcement = await Announcement.create({
        message,
        type: type || 'info',
        service: service || null,
        createdBy: userId || null
      });

      await logAction({
        actor: userId,
        actorName: userName || 'Staff',
        action: `Broadcast announcement: "${message}"`,
        entity: 'Announcement',
        entityId: announcement._id
      });

      io.emit('broadcastAnnouncement', {
        id: announcement._id,
        message: announcement.message,
        type: announcement.type,
        createdAt: announcement.createdAt
      });
    } catch (err) {
      console.error('[Socket] Failed to broadcast announcement:', err.message);
    }
  });
};

module.exports = registerNotificationSocket;
