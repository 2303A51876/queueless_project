// Handles room subscriptions so clients can subscribe to specific service
// updates (e.g. kiosk display or a user's dashboard).
const registerQueueSocket = (io, socket) => {
  socket.on('subscribeService', (serviceId) => {
    if (serviceId) {
      socket.join(`service:${serviceId}`);
    }
  });

  socket.on('unsubscribeService', (serviceId) => {
    if (serviceId) {
      socket.leave(`service:${serviceId}`);
    }
  });

  socket.on('subscribeKiosk', () => {
    socket.join('kiosk');
  });
};

module.exports = registerQueueSocket;
