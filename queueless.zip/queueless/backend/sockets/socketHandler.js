const registerQueueSocket = require('./queueSocket');
const registerNotificationSocket = require('./notificationSocket');

const initSocket = (io) => {
  io.on('connection', (socket) => {
    console.log(`[Socket] Client connected: ${socket.id}`);

    registerQueueSocket(io, socket);
    registerNotificationSocket(io, socket);

    socket.on('disconnect', () => {
      console.log(`[Socket] Client disconnected: ${socket.id}`);
    });
  });
};

module.exports = initSocket;
