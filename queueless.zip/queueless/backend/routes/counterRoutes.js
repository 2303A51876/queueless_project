const express = require('express');
const router = express.Router();
const { getCounters, createCounter, updateCounter, deleteCounter } = require('../controllers/counterController');
const authMiddleware = require('../middleware/authMiddleware');
const { adminMiddleware } = require('../middleware/roleMiddleware');

router.get('/', authMiddleware, getCounters);
router.post('/', authMiddleware, adminMiddleware, createCounter);
router.put('/:id', authMiddleware, adminMiddleware, updateCounter);
router.delete('/:id', authMiddleware, adminMiddleware, deleteCounter);

module.exports = router;
