const express = require('express');
const router = express.Router();
const {
  joinQueue,
  getMyQueues,
  snoozeToken,
  cancelToken,
  transferToken
} = require('../controllers/queueController');
const {
  listTokens,
  callNextToken,
  completeToken,
  markNoShow,
  recallToken,
  adminCancelToken
} = require('../controllers/tokenController');
const authMiddleware = require('../middleware/authMiddleware');
const { staffMiddleware } = require('../middleware/roleMiddleware');

// User-facing
router.post('/join', authMiddleware, joinQueue);
router.get('/my', authMiddleware, getMyQueues);
router.put('/:id/snooze', authMiddleware, snoozeToken);
router.put('/:id/cancel', authMiddleware, cancelToken);
router.put('/:id/transfer', authMiddleware, transferToken);

// Staff/Admin queue control
router.get('/admin/all', authMiddleware, staffMiddleware, listTokens);
router.post('/admin/next', authMiddleware, staffMiddleware, callNextToken);
router.put('/admin/:id/complete', authMiddleware, staffMiddleware, completeToken);
router.put('/admin/:id/no-show', authMiddleware, staffMiddleware, markNoShow);
router.put('/admin/:id/recall', authMiddleware, staffMiddleware, recallToken);
router.put('/admin/:id/cancel', authMiddleware, staffMiddleware, adminCancelToken);

module.exports = router;
