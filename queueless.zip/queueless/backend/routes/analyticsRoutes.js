const express = require('express');
const router = express.Router();
const { getAnalytics } = require('../controllers/analyticsController');
const authMiddleware = require('../middleware/authMiddleware');
const { staffMiddleware } = require('../middleware/roleMiddleware');

router.get('/', authMiddleware, staffMiddleware, getAnalytics);

module.exports = router;
