const express = require('express');
const router = express.Router();
const {
  getServices,
  getServiceById,
  createService,
  updateService,
  deleteService,
  pauseService,
  resumeService
} = require('../controllers/serviceController');
const authMiddleware = require('../middleware/authMiddleware');
const { adminMiddleware, staffMiddleware } = require('../middleware/roleMiddleware');
const { validateService } = require('../middleware/validationMiddleware');

router.get('/', getServices); // public
router.get('/:id', getServiceById); // public
router.post('/', authMiddleware, adminMiddleware, validateService, createService);
router.put('/:id', authMiddleware, adminMiddleware, updateService);
router.delete('/:id', authMiddleware, adminMiddleware, deleteService);
router.put('/:id/pause', authMiddleware, staffMiddleware, pauseService);
router.put('/:id/resume', authMiddleware, staffMiddleware, resumeService);

module.exports = router;
