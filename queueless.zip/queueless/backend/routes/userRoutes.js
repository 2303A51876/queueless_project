const express = require('express');
const router = express.Router();
const { getUsers, updatePriorityStatus, updateUser } = require('../controllers/userController');
const authMiddleware = require('../middleware/authMiddleware');
const { adminMiddleware } = require('../middleware/roleMiddleware');

router.get('/', authMiddleware, adminMiddleware, getUsers);
router.put('/priority-status', authMiddleware, updatePriorityStatus);
router.put('/:id', authMiddleware, adminMiddleware, updateUser);

module.exports = router;
