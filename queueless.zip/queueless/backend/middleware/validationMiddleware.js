const isEmail = (value) => /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(value);

const validateRegister = (req, res, next) => {
  const { name, email, password } = req.body;
  const errors = [];

  if (!name || name.trim().length < 2) errors.push('Name must be at least 2 characters');
  if (!email || !isEmail(email)) errors.push('A valid email is required');
  if (!password || password.length < 6) errors.push('Password must be at least 6 characters');

  if (errors.length) {
    return res.status(400).json({ success: false, message: errors.join(', ') });
  }
  next();
};

const validateLogin = (req, res, next) => {
  const { email, password } = req.body;
  if (!email || !isEmail(email) || !password) {
    return res.status(400).json({ success: false, message: 'Valid email and password are required' });
  }
  next();
};

const validateService = (req, res, next) => {
  const { name } = req.body;
  if (!name || !name.trim()) {
    return res.status(400).json({ success: false, message: 'Service name is required' });
  }
  next();
};

module.exports = { validateRegister, validateLogin, validateService };
