const Service = require('../models/Service');
const Token = require('../models/Token');
const { logAction } = require('../utils/auditLogger');

// @desc Get all services (public)
// @route GET /api/services
const getServices = async (req, res, next) => {
  try {
    const services = await Service.find().sort({ name: 1 });

    const withCounts = await Promise.all(
      services.map(async (s) => {
        const waiting = await Token.countDocuments({ service: s._id, status: 'waiting' });
        return {
          ...s.toObject(),
          waitingCount: waiting
        };
      })
    );

    res.json({ success: true, count: withCounts.length, services: withCounts });
  } catch (err) {
    next(err);
  }
};

// @desc Get single service
// @route GET /api/services/:id
const getServiceById = async (req, res, next) => {
  try {
    const service = await Service.findById(req.params.id);
    if (!service) return res.status(404).json({ success: false, message: 'Service not found' });
    res.json({ success: true, service });
  } catch (err) {
    next(err);
  }
};

// @desc Create service (admin)
// @route POST /api/services
const createService = async (req, res, next) => {
  try {
    const service = await Service.create(req.body);

    await logAction({
      actor: req.user._id,
      actorName: req.user.name,
      action: `Created service "${service.name}"`,
      entity: 'Service',
      entityId: service._id
    });

    req.io.emit('queueUpdated', { type: 'service-created', serviceId: service._id });
    res.status(201).json({ success: true, service });
  } catch (err) {
    next(err);
  }
};

// @desc Update service (admin)
// @route PUT /api/services/:id
const updateService = async (req, res, next) => {
  try {
    const service = await Service.findByIdAndUpdate(req.params.id, req.body, { new: true });
    if (!service) return res.status(404).json({ success: false, message: 'Service not found' });

    await logAction({
      actor: req.user._id,
      actorName: req.user.name,
      action: `Updated service "${service.name}"`,
      entity: 'Service',
      entityId: service._id,
      metadata: req.body
    });

    req.io.emit('queueUpdated', { type: 'service-updated', serviceId: service._id });
    res.json({ success: true, service });
  } catch (err) {
    next(err);
  }
};

// @desc Delete service (admin)
// @route DELETE /api/services/:id
const deleteService = async (req, res, next) => {
  try {
    const service = await Service.findByIdAndDelete(req.params.id);
    if (!service) return res.status(404).json({ success: false, message: 'Service not found' });

    await logAction({
      actor: req.user._id,
      actorName: req.user.name,
      action: `Deleted service "${service.name}"`,
      entity: 'Service',
      entityId: service._id
    });

    req.io.emit('queueUpdated', { type: 'service-deleted', serviceId: service._id });
    res.json({ success: true, message: 'Service deleted' });
  } catch (err) {
    next(err);
  }
};

// @desc Pause/Resume service queue (admin/staff)
// @route PUT /api/services/:id/pause  |  /resume
const setEmergencyPause = (paused) => async (req, res, next) => {
  try {
    const service = await Service.findByIdAndUpdate(
      req.params.id,
      { emergencyPause: paused, status: paused ? 'paused' : 'active' },
      { new: true }
    );
    if (!service) return res.status(404).json({ success: false, message: 'Service not found' });

    await logAction({
      actor: req.user._id,
      actorName: req.user.name,
      action: `${paused ? 'Paused' : 'Resumed'} queue for "${service.name}"`,
      entity: 'Service',
      entityId: service._id
    });

    req.io.emit('queueUpdated', { type: paused ? 'service-paused' : 'service-resumed', serviceId: service._id });
    res.json({ success: true, service });
  } catch (err) {
    next(err);
  }
};

module.exports = {
  getServices,
  getServiceById,
  createService,
  updateService,
  deleteService,
  pauseService: setEmergencyPause(true),
  resumeService: setEmergencyPause(false)
};
