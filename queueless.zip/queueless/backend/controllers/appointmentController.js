const Appointment = require('../models/Appointment');
const { logAction } = require('../utils/auditLogger');

// @desc Get appointments (own for users, all for staff/admin)
// @route GET /api/appointments
const getAppointments = async (req, res, next) => {
  try {
    const filter = req.user.role === 'user' ? { user: req.user._id } : {};
    const appointments = await Appointment.find(filter)
      .populate('user', 'name email')
      .populate('service', 'name')
      .sort({ date: 1, timeSlot: 1 });

    res.json({ success: true, count: appointments.length, appointments });
  } catch (err) {
    next(err);
  }
};

// @desc Book appointment
// @route POST /api/appointments
const createAppointment = async (req, res, next) => {
  try {
    const { serviceId, date, timeSlot } = req.body;

    const appointment = await Appointment.create({
      user: req.user._id,
      service: serviceId,
      date,
      timeSlot,
      status: 'pending'
    });

    await logAction({
      actor: req.user._id,
      actorName: req.user.name,
      action: `Booked appointment for ${date} ${timeSlot}`,
      entity: 'Appointment',
      entityId: appointment._id
    });

    req.io.emit('queueUpdated', { type: 'appointment-booked', serviceId });
    res.status(201).json({ success: true, appointment });
  } catch (err) {
    next(err);
  }
};

// @desc Update appointment (confirm/reschedule/cancel/complete/no-show)
// @route PUT /api/appointments/:id
const updateAppointment = async (req, res, next) => {
  try {
    const { status, date, timeSlot } = req.body;
    const update = {};
    if (status) update.status = status;
    if (date) update.date = date;
    if (timeSlot) update.timeSlot = timeSlot;

    const appointment = await Appointment.findByIdAndUpdate(req.params.id, update, { new: true });
    if (!appointment) return res.status(404).json({ success: false, message: 'Appointment not found' });

    await logAction({
      actor: req.user._id,
      actorName: req.user.name,
      action: `Updated appointment (${Object.keys(update).join(', ')})`,
      entity: 'Appointment',
      entityId: appointment._id,
      metadata: update
    });

    req.io.emit('queueUpdated', { type: 'appointment-updated', appointmentId: appointment._id });
    res.json({ success: true, appointment });
  } catch (err) {
    next(err);
  }
};

module.exports = { getAppointments, createAppointment, updateAppointment };
