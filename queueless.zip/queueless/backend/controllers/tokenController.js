const Token = require('../models/Token');
const Service = require('../models/Service');
const Counter = require('../models/Counter');
const { logAction } = require('../utils/auditLogger');

// @desc List/filter tokens for admin queue control table
// @route GET /api/admin/queues
const listTokens = async (req, res, next) => {
  try {
    const { service, status, priority } = req.query;
    const filter = {};
    if (service) filter.service = service;
    if (status) filter.status = status;
    if (priority) filter.priority = priority;

    const tokens = await Token.find(filter)
      .populate('user', 'name email')
      .populate('service', 'name')
      .populate('counter', 'counterNumber')
      .sort({ createdAt: -1 })
      .limit(500);

    res.json({ success: true, count: tokens.length, tokens });
  } catch (err) {
    next(err);
  }
};

// @desc Call next waiting token for a service/counter
// @route POST /api/admin/queues/next
const callNextToken = async (req, res, next) => {
  try {
    const { serviceId, counterId } = req.body;

    const counter = await Counter.findById(counterId);
    if (!counter) return res.status(404).json({ success: false, message: 'Counter not found' });

    // Priority tokens first, then FIFO by join time
    const nextToken = await Token.findOne({ service: serviceId, status: 'waiting' })
      .sort({ priority: 1, joinedAt: 1 }); // 'disability'/'senior' sort before 'none' alphabetically is unreliable; refine below

    // Explicit priority ordering: senior/disability before none
    const priorityToken = await Token.findOne({
      service: serviceId,
      status: 'waiting',
      priority: { $ne: 'none' }
    }).sort({ joinedAt: 1 });

    const tokenToCall = priorityToken || nextToken;

    if (!tokenToCall) {
      return res.status(404).json({ success: false, message: 'No waiting tokens for this service' });
    }

    tokenToCall.status = 'called';
    tokenToCall.calledAt = new Date();
    tokenToCall.counter = counterId;
    await tokenToCall.save();

    counter.currentToken = tokenToCall._id;
    await counter.save();

    const service = await Service.findByIdAndUpdate(
      serviceId,
      { currentServingToken: tokenToCall.tokenNumber },
      { new: true }
    );

    await logAction({
      actor: req.user._id,
      actorName: req.user.name,
      action: `Called Token #${tokenToCall.tokenNumber} to Counter ${counter.counterNumber}`,
      entity: 'Token',
      entityId: tokenToCall._id
    });

    req.io.emit('nextTokenCalled', {
      serviceId,
      tokenNumber: tokenToCall.tokenNumber,
      counterNumber: counter.counterNumber,
      tokenId: tokenToCall._id
    });
    req.io.emit('queueUpdated', { type: 'token-called', serviceId });

    res.json({ success: true, token: tokenToCall, service });
  } catch (err) {
    next(err);
  }
};

// @desc Mark token complete
// @route PUT /api/admin/queues/:id/complete
const completeToken = async (req, res, next) => {
  try {
    const token = await Token.findById(req.params.id);
    if (!token) return res.status(404).json({ success: false, message: 'Token not found' });

    token.status = 'completed';
    token.completedAt = new Date();
    await token.save();

    await Counter.updateMany({ currentToken: token._id }, { currentToken: null });

    await logAction({
      actor: req.user._id,
      actorName: req.user.name,
      action: `Completed Token #${token.tokenNumber}`,
      entity: 'Token',
      entityId: token._id
    });

    req.io.emit('tokenCompleted', { serviceId: token.service, tokenId: token._id });
    req.io.emit('queueUpdated', { type: 'token-completed', serviceId: token.service });

    res.json({ success: true, token });
  } catch (err) {
    next(err);
  }
};

// @desc Mark no-show
// @route PUT /api/admin/queues/:id/no-show
const markNoShow = async (req, res, next) => {
  try {
    const token = await Token.findById(req.params.id);
    if (!token) return res.status(404).json({ success: false, message: 'Token not found' });

    token.status = 'no-show';
    await token.save();
    await Counter.updateMany({ currentToken: token._id }, { currentToken: null });

    await logAction({
      actor: req.user._id,
      actorName: req.user.name,
      action: `Marked Token #${token.tokenNumber} as No-Show`,
      entity: 'Token',
      entityId: token._id
    });

    req.io.emit('queueUpdated', { type: 'no-show', serviceId: token.service });
    res.json({ success: true, token });
  } catch (err) {
    next(err);
  }
};

// @desc Re-call current token
// @route PUT /api/admin/queues/:id/recall
const recallToken = async (req, res, next) => {
  try {
    const token = await Token.findById(req.params.id).populate('counter');
    if (!token) return res.status(404).json({ success: false, message: 'Token not found' });

    await logAction({
      actor: req.user._id,
      actorName: req.user.name,
      action: `Re-called Token #${token.tokenNumber}`,
      entity: 'Token',
      entityId: token._id
    });

    req.io.emit('nextTokenCalled', {
      serviceId: token.service,
      tokenNumber: token.tokenNumber,
      counterNumber: token.counter ? token.counter.counterNumber : null,
      tokenId: token._id,
      isRecall: true
    });

    res.json({ success: true, token });
  } catch (err) {
    next(err);
  }
};

// @desc Admin cancel / transfer token
// @route PUT /api/admin/queues/:id/cancel  PUT /api/admin/queues/:id/transfer
const adminCancelToken = async (req, res, next) => {
  try {
    const token = await Token.findByIdAndUpdate(req.params.id, { status: 'cancelled' }, { new: true });
    if (!token) return res.status(404).json({ success: false, message: 'Token not found' });

    await logAction({
      actor: req.user._id,
      actorName: req.user.name,
      action: `Admin cancelled Token #${token.tokenNumber}`,
      entity: 'Token',
      entityId: token._id
    });

    req.io.emit('queueUpdated', { type: 'cancelled', serviceId: token.service });
    res.json({ success: true, token });
  } catch (err) {
    next(err);
  }
};

module.exports = {
  listTokens,
  callNextToken,
  completeToken,
  markNoShow,
  recallToken,
  adminCancelToken
};
