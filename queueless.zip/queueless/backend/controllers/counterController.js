const Counter = require('../models/Counter');
const { logAction } = require('../utils/auditLogger');

// @desc Get all counters
// @route GET /api/counters
const getCounters = async (req, res, next) => {
  try {
    const counters = await Counter.find()
      .populate('staff', 'name email')
      .populate('service', 'name')
      .populate('currentToken', 'tokenNumber')
      .sort({ counterNumber: 1 });

    res.json({ success: true, count: counters.length, counters });
  } catch (err) {
    next(err);
  }
};

// @desc Create counter (admin)
// @route POST /api/counters
const createCounter = async (req, res, next) => {
  try {
    const counter = await Counter.create(req.body);

    await logAction({
      actor: req.user._id,
      actorName: req.user.name,
      action: `Created Counter ${counter.counterNumber}`,
      entity: 'Counter',
      entityId: counter._id
    });

    req.io.emit('counterAssigned', { counterId: counter._id });
    res.status(201).json({ success: true, counter });
  } catch (err) {
    next(err);
  }
};

// @desc Update counter - assign staff, toggle status, reassign service (admin)
// @route PUT /api/counters/:id
const updateCounter = async (req, res, next) => {
  try {
    const counter = await Counter.findByIdAndUpdate(req.params.id, req.body, { new: true })
      .populate('staff', 'name')
      .populate('service', 'name');

    if (!counter) return res.status(404).json({ success: false, message: 'Counter not found' });

    await logAction({
      actor: req.user._id,
      actorName: req.user.name,
      action: `Updated Counter ${counter.counterNumber}`,
      entity: 'Counter',
      entityId: counter._id,
      metadata: req.body
    });

    req.io.emit('counterAssigned', { counterId: counter._id });
    res.json({ success: true, counter });
  } catch (err) {
    next(err);
  }
};

// @desc Delete counter (admin)
// @route DELETE /api/counters/:id
const deleteCounter = async (req, res, next) => {
  try {
    const counter = await Counter.findByIdAndDelete(req.params.id);
    if (!counter) return res.status(404).json({ success: false, message: 'Counter not found' });

    await logAction({
      actor: req.user._id,
      actorName: req.user.name,
      action: `Deleted Counter ${counter.counterNumber}`,
      entity: 'Counter',
      entityId: counter._id
    });

    res.json({ success: true, message: 'Counter deleted' });
  } catch (err) {
    next(err);
  }
};

module.exports = { getCounters, createCounter, updateCounter, deleteCounter };
