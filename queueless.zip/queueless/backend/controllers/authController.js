const bcrypt = require('bcryptjs');
const User = require('../models/User');
const generateToken = require('../utils/generateToken');
const { logAction } = require('../utils/auditLogger');

// @desc Register new user
// @route POST /api/auth/register
const register = async (req, res, next) => {
  try {
    const { name, email, password, phone } = req.body;

    const existing = await User.findOne({ email: email.toLowerCase() });
    if (existing) {
      return res.status(409).json({ success: false, message: 'An account with this email already exists' });
    }

    const salt = await bcrypt.genSalt(10);
    const hashed = await bcrypt.hash(password, salt);

    const user = await User.create({
      name,
      email: email.toLowerCase(),
      password: hashed,
      phone: phone || '',
      role: 'user'
    });

    const token = generateToken(user._id, user.role);

    await logAction({
      actor: user._id,
      actorName: user.name,
      action: 'User registered',
      entity: 'User',
      entityId: user._id
    });

    res.status(201).json({
      success: true,
      token,
      user: {
        id: user._id,
        name: user.name,
        email: user.email,
        role: user.role,
        priorityStatus: user.priorityStatus
      }
    });
  } catch (err) {
    next(err);
  }
};

// @desc Login
// @route POST /api/auth/login
const login = async (req, res, next) => {
  try {
    const { email, password } = req.body;

    const user = await User.findOne({ email: email.toLowerCase() }).select('+password');
    if (!user) {
      return res.status(401).json({ success: false, message: 'Invalid email or password' });
    }
    if (!user.isActive) {
      return res.status(403).json({ success: false, message: 'This account has been deactivated' });
    }

    const isMatch = await bcrypt.compare(password, user.password);
    if (!isMatch) {
      return res.status(401).json({ success: false, message: 'Invalid email or password' });
    }

    const token = generateToken(user._id, user.role);

    await logAction({
      actor: user._id,
      actorName: user.name,
      action: 'User logged in',
      entity: 'User',
      entityId: user._id
    });

    res.json({
      success: true,
      token,
      user: {
        id: user._id,
        name: user.name,
        email: user.email,
        role: user.role,
        priorityStatus: user.priorityStatus
      }
    });
  } catch (err) {
    next(err);
  }
};

// @desc Get current user
// @route GET /api/auth/me
const getMe = async (req, res, next) => {
  try {
    res.json({
      success: true,
      user: {
        id: req.user._id,
        name: req.user.name,
        email: req.user.email,
        role: req.user.role,
        priorityStatus: req.user.priorityStatus,
        phone: req.user.phone
      }
    });
  } catch (err) {
    next(err);
  }
};

module.exports = { register, login, getMe };
