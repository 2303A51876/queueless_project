const AuditLog = require('../models/AuditLog');

// @desc Get audit logs (admin)
// @route GET /api/audit-logs
const getAuditLogs = async (req, res, next) => {
  try {
    const logs = await AuditLog.find().sort({ timestamp: -1 }).limit(300);
    res.json({ success: true, count: logs.length, logs });
  } catch (err) {
    next(err);
  }
};

module.exports = { getAuditLogs };
