const Token = require('../models/Token');
const Service = require('../models/Service');
const { estimateWaitMinutes, nextTokenNumber } = require('../utils/queueUtils');
const { logAction } = require('../utils/auditLogger');

// @desc Join a live queue
// @route POST /api/queues/join
const joinQueue = async (req, res, next) => {
  try {
    const { serviceId } = req.body;
    const service = await Service.findById(serviceId);
    if (!service) return res.status(404).json({ success: false, message: 'Service not found' });
    if (service.status !== 'active' || service.emergencyPause) {
      return res.status(400).json({ success: false, message: 'This queue is currently paused' });
    }

    const existing = await Token.findOne({
      user: req.user._id,
      service: serviceId,
      status: { $in: ['waiting', 'called', 'serving'] }
    });
    if (existing) {
      return res.status(409).json({ success: false, message: 'You already have an active token for this service' });
    }

    const tokenNumber = nextTokenNumber(service.lastTokenNumber);
    service.lastTokenNumber = tokenNumber;
    await service.save();

    const joinedAt = new Date();
    const token = await Token.create({
      tokenNumber,
      user: req.user._id,
      service: serviceId,
      priority: req.user.priorityStatus,
      joinedAt,
      qrPayload: `QUEUELESS:${serviceId}:${tokenNumber}:${Date.now()}`
    });

    token.estimatedWaitMinutes = await estimateWaitMinutes({
      serviceId,
      averageServiceTime: service.averageServiceTime,
      priority: token.priority,
      joinedAt
    });
    await token.save();

    await logAction({
      actor: req.user._id,
      actorName: req.user.name,
      action: `Joined queue for "${service.name}" (Token #${tokenNumber})`,
      entity: 'Token',
      entityId: token._id
    });

    req.io.emit('queueUpdated', { type: 'joined', serviceId, tokenId: token._id });

    res.status(201).json({ success: true, token });
  } catch (err) {
    next(err);
  }
};

// @desc Get my active + recent tokens
// @route GET /api/queues/my
const getMyQueues = async (req, res, next) => {
  try {
    const tokens = await Token.find({ user: req.user._id })
      .populate('service', 'name averageServiceTime')
      .populate('counter', 'counterNumber')
      .sort({ createdAt: -1 });

    res.json({ success: true, count: tokens.length, tokens });
  } catch (err) {
    next(err);
  }
};

// @desc Snooze / delay a token
// @route PUT /api/queues/:id/snooze
const snoozeToken = async (req, res, next) => {
  try {
    const token = await Token.findById(req.params.id);
    if (!token) return res.status(404).json({ success: false, message: 'Token not found' });
    if (String(token.user) !== String(req.user._id)) {
      return res.status(403).json({ success: false, message: 'Not your token' });
    }
    if (!['waiting', 'called'].includes(token.status)) {
      return res.status(400).json({ success: false, message: 'Token cannot be snoozed in its current state' });
    }

    const minutes = Number(req.body.minutes) || 10;
    token.snoozeUntil = new Date(Date.now() + minutes * 60 * 1000);
    await token.save();

    await logAction({
      actor: req.user._id,
      actorName: req.user.name,
      action: `Snoozed Token #${token.tokenNumber} for ${minutes} mins`,
      entity: 'Token',
      entityId: token._id
    });

    req.io.emit('queueUpdated', { type: 'snoozed', serviceId: token.service, tokenId: token._id });
    res.json({ success: true, token });
  } catch (err) {
    next(err);
  }
};

// @desc Cancel a token
// @route PUT /api/queues/:id/cancel
const cancelToken = async (req, res, next) => {
  try {
    const token = await Token.findById(req.params.id);
    if (!token) return res.status(404).json({ success: false, message: 'Token not found' });
    if (String(token.user) !== String(req.user._id) && req.user.role === 'user') {
      return res.status(403).json({ success: false, message: 'Not your token' });
    }

    token.status = 'cancelled';
    await token.save();

    await logAction({
      actor: req.user._id,
      actorName: req.user.name,
      action: `Cancelled Token #${token.tokenNumber}`,
      entity: 'Token',
      entityId: token._id
    });

    req.io.emit('queueUpdated', { type: 'cancelled', serviceId: token.service, tokenId: token._id });
    res.json({ success: true, token });
  } catch (err) {
    next(err);
  }
};

// @desc Transfer token to another service
// @route PUT /api/queues/:id/transfer
const transferToken = async (req, res, next) => {
  try {
    const { newServiceId } = req.body;
    const token = await Token.findById(req.params.id);
    if (!token) return res.status(404).json({ success: false, message: 'Token not found' });
    if (String(token.user) !== String(req.user._id)) {
      return res.status(403).json({ success: false, message: 'Not your token' });
    }

    const newService = await Service.findById(newServiceId);
    if (!newService) return res.status(404).json({ success: false, message: 'Target service not found' });

    token.status = 'transferred';
    await token.save();

    const tokenNumber = nextTokenNumber(newService.lastTokenNumber);
    newService.lastTokenNumber = tokenNumber;
    await newService.save();

    const joinedAt = new Date();
    const newToken = await Token.create({
      tokenNumber,
      user: req.user._id,
      service: newServiceId,
      priority: req.user.priorityStatus,
      joinedAt,
      qrPayload: `QUEUELESS:${newServiceId}:${tokenNumber}:${Date.now()}`
    });

    await logAction({
      actor: req.user._id,
      actorName: req.user.name,
      action: `Transferred Token #${token.tokenNumber} to "${newService.name}"`,
      entity: 'Token',
      entityId: newToken._id
    });

    req.io.emit('queueUpdated', { type: 'transferred', serviceId: newServiceId });
    res.json({ success: true, oldToken: token, newToken });
  } catch (err) {
    next(err);
  }
};

module.exports = { joinQueue, getMyQueues, snoozeToken, cancelToken, transferToken };
