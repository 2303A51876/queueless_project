const User = require('../models/User');
const { logAction } = require('../utils/auditLogger');

// @desc Get all users (admin)
// @route GET /api/users
const getUsers = async (req, res, next) => {
  try {
    const users = await User.find().sort({ createdAt: -1 });
    res.json({ success: true, count: users.length, users });
  } catch (err) {
    next(err);
  }
};

// @desc Update own priority status
// @route PUT /api/users/priority-status
const updatePriorityStatus = async (req, res, next) => {
  try {
    const { priorityStatus } = req.body;
    if (!['none', 'senior', 'disability'].includes(priorityStatus)) {
      return res.status(400).json({ success: false, message: 'Invalid priority status value' });
    }

    const user = await User.findByIdAndUpdate(
      req.user._id,
      { priorityStatus },
      { new: true }
    );

    await logAction({
      actor: user._id,
      actorName: user.name,
      action: `Priority status set to ${priorityStatus}`,
      entity: 'User',
      entityId: user._id
    });

    res.json({ success: true, priorityStatus: user.priorityStatus });
  } catch (err) {
    next(err);
  }
};

// @desc Update user role / status (admin)
// @route PUT /api/users/:id
const updateUser = async (req, res, next) => {
  try {
    const { role, isActive } = req.body;
    const update = {};
    if (role) update.role = role;
    if (typeof isActive === 'boolean') update.isActive = isActive;

    const user = await User.findByIdAndUpdate(req.params.id, update, { new: true });
    if (!user) return res.status(404).json({ success: false, message: 'User not found' });

    await logAction({
      actor: req.user._id,
      actorName: req.user.name,
      action: 'Updated user record',
      entity: 'User',
      entityId: user._id,
      metadata: update
    });

    res.json({ success: true, user });
  } catch (err) {
    next(err);
  }
};

module.exports = { getUsers, updatePriorityStatus, updateUser };
