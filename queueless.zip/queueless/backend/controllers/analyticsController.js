const Token = require('../models/Token');
const Service = require('../models/Service');
const User = require('../models/User');

// @desc Get analytics summary for admin dashboard
// @route GET /api/analytics
const getAnalytics = async (req, res, next) => {
  try {
    const [totalUsers, services] = await Promise.all([
      User.countDocuments({ role: 'user' }),
      Service.find()
    ]);

    const statusByService = await Promise.all(
      services.map(async (s) => {
        const [waiting, serving, completed, cancelled] = await Promise.all([
          Token.countDocuments({ service: s._id, status: 'waiting' }),
          Token.countDocuments({ service: s._id, status: { $in: ['called', 'serving'] } }),
          Token.countDocuments({ service: s._id, status: 'completed' }),
          Token.countDocuments({ service: s._id, status: { $in: ['cancelled', 'no-show'] } })
        ]);
        return { service: s.name, waiting, serving, completed, cancelled };
      })
    );

    const activeQueues = await Token.countDocuments({ status: { $in: ['waiting', 'called', 'serving'] } });

    const todayStart = new Date();
    todayStart.setHours(0, 0, 0, 0);
    const servedToday = await Token.countDocuments({ status: 'completed', completedAt: { $gte: todayStart } });

    const completedTokens = await Token.find({ status: 'completed', calledAt: { $ne: null }, completedAt: { $ne: null } })
      .select('calledAt completedAt')
      .limit(1000);

    let avgHandlingTime = 0;
    if (completedTokens.length) {
      const totalMinutes = completedTokens.reduce((sum, t) => {
        return sum + (new Date(t.completedAt) - new Date(t.calledAt)) / 60000;
      }, 0);
      avgHandlingTime = Math.round(totalMinutes / completedTokens.length);
    }

    // Peak-hour heatmap: count of tokens joined per hour of day per service
    const allTokens = await Token.find().select('service joinedAt').populate('service', 'name');
    const heatmap = {};
    allTokens.forEach((t) => {
      const hour = new Date(t.joinedAt).getHours();
      const serviceName = t.service ? t.service.name : 'Unknown';
      const key = `${serviceName}-${hour}`;
      heatmap[key] = (heatmap[key] || 0) + 1;
    });
    const heatmapData = Object.entries(heatmap).map(([key, count]) => {
      const [service, hour] = key.split('-');
      return { service, hour: Number(hour), count };
    });

    const activeVsCompleted = {
      active: activeQueues,
      completed: await Token.countDocuments({ status: 'completed' })
    };

    res.json({
      success: true,
      totalUsers,
      activeQueues,
      servedToday,
      avgHandlingTime,
      statusByService,
      activeVsCompleted,
      heatmap: heatmapData
    });
  } catch (err) {
    next(err);
  }
};

module.exports = { getAnalytics };
